import bpy
import os
#from .asw_rig._0_find_bone_names import find_bone_names

# Initiate rigify.
# Move bone layers.
# Assing rig types.
# Assign super_copy.
# Fix rig based on the game rig. (rotation, lengths, etc.)
# Align bones.
#
# Generate rig.
# Fix rigify bone layers and groups.
# Add twist bones constraints.
# Add DEF- to vertex groups names.

class ASW_OT_GenerateMetarig(bpy.types.Operator):
    bl_label = "Generate Arc System Works Metarig Rig"
    bl_idname = "asw.generate_metarig"
    bl_description = "Generates a metarig from the active arc system works rig"
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(self, context):
        if not context.object:
            return False
        return context.object.type == 'ARMATURE' # Is armature?
    
    def execute(self, context):
        
        script_dir = os.path.dirname(os.path.realpath(__file__))

        # TODO: Fix for macos, I think it won't find the files becasue it uses \.
        bpy.ops.script.python_file_run(filepath=script_dir+"\\asw_rig\\_0_find_bone_names.py")
        bpy.ops.script.python_file_run(filepath=script_dir+"\\asw_rig\\_1_initiate_rigify.py")
        bpy.ops.script.python_file_run(filepath=script_dir+"\\asw_rig\\_2_move_bone_layers.py")
        bpy.ops.script.python_file_run(filepath=script_dir+"\\asw_rig\\_3_assign_rig_types.py")
        bpy.ops.script.python_file_run(filepath=script_dir+"\\asw_rig\\_4_fix_metarig_arc_system_works.py")
        bpy.ops.script.python_file_run(filepath=script_dir+"\\asw_rig\\_5_align_connect_bones.py")
        bpy.ops.script.python_file_run(filepath=script_dir+"\\asw_rig\\_6_assign_super_copy.py")
        
        self.report({'INFO'}, 'Succesfully generated: "arc_system_works metarig"')

        return {'FINISHED'}

# ===========================

def register():
    bpy.utils.register_class(ASW_OT_GenerateMetarig)

def unregister():
    bpy.utils.unregister_class(ASW_OT_GenerateMetarig)