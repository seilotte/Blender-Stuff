import bpy
import os

def append_something(node_tree_name):
    geo_nodes = bpy.data.node_groups.get(node_tree_name)
    
    if not geo_nodes:
        script_dir = os.path.dirname(os.path.realpath(__file__))
        
        # Append outline geometry nodes.
        bpy.ops.wm.append(directory = script_dir + '\\Arc_System_Works_Shaders.blend\\NodeTree', filename = node_tree_name)

class ASW_OT_AddOutlines(bpy.types.Operator):
    bl_label = 'Generate Outlines'
    bl_idname = 'asw.add_outlines'
    bl_description = 'Generate solidfy outlines and set-up geometry nodes'
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):

        append_something('_ASW Outline - v1.4')
        
        all = context.selected_objects
        for obj in all:
            if obj.type != 'MESH':
                continue
            
            

        return{'FINISHED'}

# ===========================

def register():
    bpy.utils.register_class(ASW_OT_AddOutlines)

def unregister():
    bpy.utils.unregister_class(ASW_OT_AddOutlines)