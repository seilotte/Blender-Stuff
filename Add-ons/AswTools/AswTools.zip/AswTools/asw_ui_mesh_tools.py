import bpy
from bpy.types import Panel

# Global panel UI properties.
class AswPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ASW'

# Create data tools UI panel.
class ASW_PT_MeshTools(AswPanel, Panel):
    bl_label = 'Mesh Tools'
    bl_idname = 'ASW_PT_meshtools'
#    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        vars = context.scene.asw_variables
        layout = self.layout
        
        col = layout.column(align=True)
        col.operator('asw.fix_mesh', text='Fix Mesh', icon='MESH_DATA')

        layout.separator()

        col = layout.column(align=True)
        col.operator('asw.add_outlines', text='Outline', icon='MOD_SOLIDIFY')
        col.prop(vars, 'outline_sharp_edges')

# Create nodes data UI subpanel.
class ASW_PT_NodesData(AswPanel, Panel):
    bl_label = 'Nodes Data'
    bl_parent_id = 'ASW_PT_meshtools'
#    bl_option = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        vars = context.scene.asw_variables
        layout = self.layout
        
        col = layout.column(align=True)
        col.prop(vars, 'dir', text='')
        col.operator('asw.batch_materials', text='Auto Texture', icon='IMAGE_DATA')

# ===========================

classes = [
    ASW_PT_MeshTools,
    ASW_PT_NodesData,
]
def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)