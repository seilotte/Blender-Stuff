import bpy
import bmesh

class ASW_OT_FixMesh(bpy.types.Operator):
    bl_label = 'Fix Mesh'
    bl_idname = 'asw.fix_mesh'
    bl_description = 'Removes duped materials and vertices from "shadow" and "outline" materials'
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        
        all = bpy.context.selected_objects
        remove_mat_names = ['outline', '_1', 'shadow', '_2', 'uniqueb'] # Line 29.
        
        for obj in all:
            if obj.type != 'MESH':
                continue

# =========================== Remove vertices from materials.

            # Create a bmesh from the mesh data.
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            
            for mat_slot in obj.material_slots:
                
                # Search for wanted materials.
                for i in remove_mat_names: # i = numbers; n = name
                    if i in mat_slot.name.lower():
                        mat_index = obj.material_slots.find(mat_slot.name)
                        
                        # Remove vertices.
                        verts_to_remove = []
                        for face in bm.faces:
                            if face.material_index == mat_index:
                                for loop in face.loops:
#                                    bm.verts.remove(loop.vert) # I crashed with high vertex count.
                                    if loop.vert not in verts_to_remove: # Fix for above.
                                        verts_to_remove.append(loop.vert)
#                        
                        for vertex in verts_to_remove:
                            if vertex.is_valid:
                                bm.verts.remove(vertex)
                        
                        del verts_to_remove
                        print(f'Deleted vertices from: "{mat_slot.name}"')
                
            # Update the mesh data with the modified bmesh.
            bm.to_mesh(obj.data)
            obj.data.update()

# =========================== Material names and duplicated materials.

            # Add prefix from mesh to the material name.
            for mat_slot in obj.material_slots:
                if mat_slot.name[:4] != obj.name[:4]:
                    mat_slot.material.name = obj.name[:4] + mat_slot.name


            # Fix enumeration of names.
#            name_counter = 0
            for mat_slot in obj.material_slots:
                split_name = mat_slot.name.split('.')[0] # Name before dot.
                
                if len(mat_slot.name.split('.')) > 1:
                    # Check if the name has been encountered before.
                    if split_name not in obj.material_slots:
                        mat_slot.material.name = split_name
    #                    name_counter = 1
                    else:
                        # Remove duplicated materials.
                        duped_mat_name = mat_slot.material.name
                        
                        mat_slot.material = obj.material_slots[split_name].material
                        bpy.data.materials.remove(bpy.data.materials[duped_mat_name])
                        
                        print(f'Removed: "{duped_mat_name}"')
    #                    mat_slot.material.name = f'{split_name}.{str(name_counter).zfill(3)}' # zfill(3) = 000
    #                    name_counter += 1

# =========================== Move to collections.

        def unlink_object_from_collection(object):
            if object.name in bpy.context.scene.collection:
                bpy.context.scene.collection.objects.unlink(object)
            else:
                object.users_collection[0].objects.unlink(object)

        # TODO: There's a few issues with meshes that don't fulfill the requirements.
        # It can be fixed with a smarter way of using the two for loops.
        # For example, creating the collections first, then assign the objects to them.
        for obj in all:
            if obj.type != 'MESH':
                continue

            # Fix mesh name.
            obj.name = obj.name.split('.')[0]
            obj.data.name = obj.name.split('.')[0]

            # Main collection name.
            obj_prefix = obj.name.split('_')[0]
            collection_name = obj_prefix if obj_prefix.isupper() else obj_prefix.capitalize()

            # Create main collection.
            if not bpy.data.collections.get(collection_name):
                main_collection = bpy.data.collections.new(collection_name)

                # Create sub-collections.
                collection_prefix = collection_name
                rigs_collection = bpy.data.collections.new(collection_prefix + ' Rigs')
                mesh_collection = bpy.data.collections.new(collection_prefix + ' Mesh')

                main_collection.children.link(rigs_collection)
                main_collection.children.link(mesh_collection)

                # Link main collection to the scene.
                bpy.context.scene.collection.children.link(main_collection)

            unlink_object_from_collection(obj)
            mesh_collection.objects.link(obj) # Add object to collections.

            if obj.parent:
                # Fix name.
#                prefix = obj.name.split('_')[0]
                prefix = obj.name.split('.')[0]

                obj.parent.name = prefix + '_metarig'
                obj.parent.data.name = prefix + '_metarig'

                unlink_object_from_collection(obj.parent)
                rigs_collection.objects.link(obj.parent) # Add parent to collection.


        x = 0 # Armature and mesh selected?
        for obj in all:
            if obj.type == 'ARMATURE':
                x += 1
                continue
            elif obj.type == 'MESH':
                x += 1
                break

        if x > 2:
            for obj in all: # Another for-loop since armatures came first than meshes.
                if obj.type != 'ARMATURE':
                    continue
                
                obj_prefix = obj.name.split('_')[0]
                collection_name = obj_prefix if obj_prefix.isupper() else obj_prefix.capitalize()
                
                rig_collection = bpy.data.collections.get(collection_name + ' Rigs')
                if rig_collection and obj.name not in rig_collection:
                    unlink_object_from_collection(obj)
                    rig_collection.objects.link(obj)
                else:
                    unlink_object_from_collection(obj)
                    rigs_collection.objects.link(obj)

        return{'FINISHED'}

# ===========================

def register():
    bpy.utils.register_class(ASW_OT_FixMesh)

def unregister():
    bpy.utils.unregister_class(ASW_OT_FixMesh)