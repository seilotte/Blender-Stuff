import bpy
from bpy.types import Panel

# Global panel UI properties.
class AswPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ASW'

# Create omo test UI panel.
class ASW_PT_omo(AswPanel, Panel):
    bl_label = 'omo'
    bl_idname = "ASW_PT_omo"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        pass

# ===========================

def register():
    bpy.utils.register_class(ASW_PT_omo)

def unregister():
    bpy.utils.unregister_class(ASW_PT_omo)