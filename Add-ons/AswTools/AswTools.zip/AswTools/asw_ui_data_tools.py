import bpy
from bpy.types import Panel, Operator

# Make all armatures, stick and in front.
class ASW_OT_StickInFront(bpy.types.Operator):
    bl_label = 'Armatures Stick, In Front'
    bl_idname = 'asw.stick_infront'
    bl_description = 'Display all armatures as "Stick" and "In Front"'
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        
#        for o in context.scene.objects:
        for o in context.selected_objects:
            if o.type == 'ARMATURE':
                o.data.display_type = 'STICK'
                o.show_in_front = True

        return{'FINISHED'}

# ===========================

# Global panel UI properties.
class AswPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ASW'

# Create data tools UI panel.
class ASW_PT_DataTools(AswPanel, Panel):
    bl_label = 'Data Tools'
    bl_idname = 'ASW_PT_datatools'
#    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        
        col = layout.column(align=True)
        col.prop(context.scene.asw_variables, 'from_armature', text='Rig')
        col.operator('asw.assign_rig', text='Assign Armature', icon='OUTLINER_OB_ARMATURE')
#        row = col.split(factor=0.5, align=True)
#        row.operator('asw.stick_infront', text='Stick | In Front', icon='ARMATURE_DATA')
        col.operator('asw.stick_infront', text='Stick | In Front', icon='ARMATURE_DATA')

        layout.separator()

        layout.operator('outliner.orphans_purge', text='Purge', icon='TRASH').do_recursive = True
 
# ===========================

classes = [
    ASW_OT_StickInFront,
    ASW_PT_DataTools,
]
def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)