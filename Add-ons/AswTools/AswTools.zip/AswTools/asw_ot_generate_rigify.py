import bpy
import os

# Generate rig.
# Fix rigify bone layers and groups.
# Add twist bones constraints.
# Add DEF- to vertex groups names.

class ASW_OT_GenerateRigify(bpy.types.Operator):
    bl_label = "Generate Arc System Works Rig"
    bl_idname = "asw.generate_rigify"
    bl_description = "Generates an enhanced rigify rig from the active arc system works metarig"
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(self, context):
        if not context.object:
            return False
        return context.object.type == 'ARMATURE'
    
    def execute(self, context):

        script_dir = os.path.dirname(os.path.realpath(__file__))
        
        # TODO: Fix for macos, I think it won't find the files becasue it uses \.
        bpy.ops.script.python_file_run(filepath=script_dir+"\\asw_rig\\0_generate_fix_rig.py")
        
#        # Face check.
#        for b in context.view_layer.objects.active.data.bones:
#            if b.layers[2]:
#                bpy.ops.script.python_file_run(filepath=script_dir+"\\asw_rig\\7generate_fix_face_rig.py")
#                break
        
        self.report({'INFO'}, 'Succesfully generated: "arc_system_works rig"')

        return {'FINISHED'}

# ===========================

def register():
    bpy.utils.register_class(ASW_OT_GenerateRigify)

def unregister():
    bpy.utils.unregister_class(ASW_OT_GenerateRigify)