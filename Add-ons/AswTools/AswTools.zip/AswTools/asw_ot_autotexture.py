import bpy
import os

tex_sets = [ # Needs lower case.
    'base',
    'sss',
    'ilm',
    'detail',
    'decal',
    'damage',
    'olm',
]

mat_sets = {
    'base': '_- Strive - Arc System Works',
    'outline': '_Outline',
    'shadow': '_Shadow',
    'decal': '_Decal/Damage',
    'glow': '_Glow'
}

# TODO: This executes multiple times, just do once (below).
def search_directory(root_dir, file_name):
    shortest_file = None

    for subdir, dirs, files in os.walk(root_dir):
        for file in files:
            # Ignore .txt and .mat files.
            if file.endswith('txt') or file.endswith('mat'):
                continue
            
            # Get shortest file name from directory.
            if file_name in file.lower():
                if shortest_file is None or len(file) < len(shortest_file):
                    shortest_file = file
                    file_path = os.path.join(subdir, shortest_file)

        if shortest_file and file_path:
            return shortest_file, file_path
            shortest_file = None # Reset for next iteration.
    
    return None, None

# TODO: Just append materials once.
def set_material(obj, mat_slot, from_mat_name):
    script_dir = os.path.dirname(os.path.realpath(__file__))
    
    # Append material.
    bpy.ops.wm.append(directory = script_dir + '\\Arc_System_Works_Shaders.blend\\Material', filename = from_mat_name)
    
    mat_to_copy = bpy.data.materials.get(from_mat_name)
    mat_name = mat_slot.name
    
    # Material name.
    obj_prefix = obj.name.split('_')[0]
    new_mat_name = mat_name.split('.')[0]
    new_mat_name = obj_prefix +'_' + new_mat_name.split('_')[-1]
    
    if not mat_to_copy:
        print(f'{from_mat_name}: Material not found.')
    else:
        mat_exists = bpy.data.materials.get(new_mat_name)
        if mat_exists:
            mat_slot.material = mat_exists
        else:
            mat_slot.material = mat_to_copy.copy()
        
        # Remove material from file.
        bpy.data.materials.remove(mat_to_copy)
        bpy.data.materials.remove(bpy.data.materials[mat_name])

        mat_slot.material.name = new_mat_name

#def dedup_mat_nodes(mat_slot):
#    mat_tree = mat_slot.material.node_tree

#    for node in mat_tree.nodes:
#        if node.type == 'GROUP':
#            node_name = node.node_tree.name
#            split_name = node_name.split('.')

#            if len(split_name) > 1: # Is duped?
#                org_node = bpy.data.node_groups[split_name[0]]
#                node.node_tree = org_node
#                bpy.data.node_groups.remove(bpy.data.node_groups[node_name])

def clean_duped_nodes():
    for node in bpy.data.node_groups:
        split_name = node.name.split('.')
        # Prefix has "_" so we don't delete yours.
        if len(split_name) > 1 and split_name[0].startswith('_'): # Is duped?
            bpy.data.node_groups.remove(node)

# ===========================

class ASW_OT_BatchAswMats(bpy.types.Operator):
    bl_label = 'Auto-map Materials'
    bl_idname = 'asw.batch_materials'
    bl_description = "Batch process Arc System Works materials"
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        
        vars = bpy.context.scene.asw_variables
        all = bpy.context.selected_objects
        
        x = True # Already printed?
        for obj in all:
            if obj.type != 'MESH':
                continue

            if vars.dir == '':
                if x:
                    print('Folder path not set.')
                    x = False
            else:
                for mat_slot in obj.material_slots:
                    # Assign material from .blend.
                    for mat_set, asw_mat_name in mat_sets.items():
                        if mat_set in mat_slot.name.lower():
                            set_material(obj, mat_slot, asw_mat_name)
            #                dedup_mat_nodes(mat_slot)
            #                clean_duped_nodes()
                            break

                    mat = bpy.data.materials[mat_slot.name]
                    mat_tree = mat.node_tree

                    # Search for images.
                    for tex_set in tex_sets:
                        image_name, image_path = search_directory(vars.dir, tex_set)
                        if not image_path:
                            print(f'{tex_set}, {mat_slot.name}: Image not found, skipping...')
                            continue

                        # Get image (blender).
                        tex_image = bpy.data.images.get(image_name)
                        if not tex_image:
                            tex_image = bpy.data.images.load(image_path)
                        
                        if tex_image:
                            # Get image node; Conviniently I named them like the tex_sets.
                            image_node = mat_tree.nodes.get(tex_set)
                            if image_node: # Node settings.
                                image_node.image = tex_image
                                if tex_set in ['ilm', 'decal', 'damage', 'olm']:
                                    image_node.image.colorspace_settings.name = 'Linear'
                                image_node.image.alpha_mode = 'CHANNEL_PACKED'

                clean_duped_nodes()

        # Delte extra suns.
        for light in bpy.data.lights:
            split_name = light.name.split('.')
            
            if len(split_name) > 1:
                if split_name[0] == '_Sun [DO NOT DELETE]':
                    bpy.data.lights.remove(light)

        return{'FINISHED'}

# ===========================

def register():
    bpy.utils.register_class(ASW_OT_BatchAswMats)

def unregister():
    bpy.utils.unregister_class(ASW_OT_BatchAswMats)