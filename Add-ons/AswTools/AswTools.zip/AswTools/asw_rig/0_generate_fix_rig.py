import bpy
from AswTools.rig_utils import custom_strings

vars = bpy.context.scene.asw_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.
metarig_name = obj.name

x = 0 # Metarig has rig type?
if obj.type == 'ARMATURE':
    for b in obj.data.bones:
        if len(obj.pose.bones.get(b.name).rigify_type) > 0:
            x += 1
            break

# ===========================

def move_bone_layer(lyr):
    b.layers = [layer == lyr for layer in range(32)]

def assign_bone_group(bone_name, group):
    o.pose.bones[bone_name].bone_group = o.pose.bone_groups[group]
#    o.pose.bones.get(bone_name).bone_group = o.pose.bone_groups.get(group)

def twist_bone(bone_name, hand_tweak,  lowarm_tweak, infl):
    b = o.pose.bones[bone_name]
    if b:
        constraint = b.constraints.new('COPY_ROTATION')
        constraint.target = o # o = rigify armature
        constraint.subtarget = hand_tweak
        constraint.use_x = False
        constraint.use_y = True
        constraint.invert_y = True # Arc sys rig (fortune) gltf rolls.
        constraint.use_z = False
        constraint.target_space = 'CUSTOM'
        constraint.owner_space = 'LOCAL'
        constraint.space_object = o
        constraint.space_subtarget = lowarm_tweak
        constraint.influence = infl
#    print(f'TWIST: "{b.name}"')

# Only use if _L, .L is in the name.
# From name_L; add_to_str: '_example'; To name_example_L
def rigify_name(string, add_to_str):
    string = f'{string[:-2]}{add_to_str}{string[-2:]}'
    return string

# ===========================

vars_lists = custom_strings(vars)

# Rigify rig name.
split_name = metarig_name.split('_')
rig_name = metarig_name.replace('_' + split_name[-1], '')

if x > 0:
    del x
    bpy.ops.pose.rigify_generate()
    
    
    o = bpy.context.view_layer.objects.get('RIG-' + rig_name) # o = rigify rig
#    activeMode = o.mode
    
    if o.type == 'ARMATURE':
        vars.from_armature = o
        obj.hide_viewport = True
        obj.hide_render = True
        
        o.show_in_front = True
        
        # Make certain layers active.
        for c in range(32):
            o.data.layers[c] = False
        for i in [2, 5, 8, 11, 14, 17, 20, 22, 28]:
            o.data.layers[i] = True
        
# =========================== Start lists.
        
        arms_legs_list = []
        for i in vars_lists:
            if i.startswith(('arm', 'leg')):
                arms_legs_list = vars_lists[i][:1] + arms_legs_list
        
        l = vars_lists['legL'][-2] # foot_L
        r = vars_lists['legR'][-2] # foot_R
        
        arms_legs_list_ik = [rigify_name(l, '_spin_ik'), rigify_name(r, '_spin_ik')] # I like having the foot ik in the extra layer.
        for i in arms_legs_list:
            arms_legs_list_ik.append(rigify_name(i, '_ik'))
        
        arms_legs_list_parent = []
        for i in arms_legs_list:
            arms_legs_list_parent.append(rigify_name(i, '_parent'))
        
        arms_legs_list_pole = []
        for i in arms_legs_list_ik:
            arms_legs_list_pole.append(f'VIS_{i[:-2]}_pole{i[-2:]}')

# =========================== End lists.

        for b in o.data.bones:
            
            # Move bone layers.
            # Extra, from arms and legs.
            if b.name in arms_legs_list_ik:
                move_bone_layer(26) # Extra
            
            elif b.name in arms_legs_list_parent:
                move_bone_layer(26)
                o.pose.bones.get(b.name)['pole_vector'] = 1
                o.pose.bones.get(b.name)['IK_Stretch'] = 0
            
            
            # Assign bone groups.
            elif b.name in arms_legs_list_pole:
                assign_bone_group(b.name, 'Root')
            
            
            # Fix bone head size and position.
            elif b.name == 'head':
                o.pose.bones[b.name].custom_shape_scale_xyz[0] = 2.0
                o.pose.bones[b.name].custom_shape_scale_xyz[1] = 2.0 # Translates on y.
                o.pose.bones[b.name].custom_shape_scale_xyz[2] = 2.0
#                    o.pose.bones[b.name].custom_shape_translation[1] = 0.05


        # Twist bones constraints.
        # Define bone names for twist_bone().
        bones = { # name_tweak
            'forearm': {'L': rigify_name(vars.arm1_L, '_tweak'), 'R': rigify_name(vars.arm1_R, '_tweak')}, # lowarm
            'hand': {'L': rigify_name(vars.arm2_L, '_tweak'), 'R': rigify_name(vars.arm2_R, '_tweak')},
            'foreleg': {'L': rigify_name(vars_lists['legL'][1], '_tweak'), 'R': rigify_name(vars_lists['legR'][1], '_tweak')}, # calf
            'foot': {'L': rigify_name(vars_lists['legL'][-2], '_tweak'), 'R': rigify_name(vars_lists['legR'][-2], '_tweak')},
        }
        
        twist_values = {
            'up': 0.25,
            'mid': 0.5,
            'low': 0.8,
            'wrist': 0.9,
        }
        
        ignore_substrings = {
            'muslce', 'scl', 'z', 'belt',
            'G_up', # Strive
            'GP', # FighterZ
            'wrist_down', 'wrist_up', # Xrd
            'GDP', # DNF Duel
        }
        
        for b in o.data.bones:
            # Only use Extreme Deform layer.
            if not b.layers[27]:
                continue
            
            # Ignore bones.
            if any(i in b.name for i in ignore_substrings):
                continue
            
            # Check for left or right.
            if '_L' in b.name:
                side = 'L'
            elif '_R' in b.name:
                side = 'R'
            
            # Twist value.
            twist_value = 0.0
            for i in twist_values:
                if i in b.name.lower():
                    twist_value = twist_values[i]
                    break
            
            # Arms.
            if vars.arm1_L[2:-2] in b.name or 'wrist_' in b.name: # lowarm
                twist_bone(b.name, bones['forearm'][side], bones['hand'][side], twist_value)
            # Legs.
            elif vars_lists['legL'][1][2:-2] in b.name: # calf
                twist_bone(b.name, bones['foreleg'][side], bones['foot'][side], twist_value)

print(f'{o.name}: Fixed rigify body rig.')