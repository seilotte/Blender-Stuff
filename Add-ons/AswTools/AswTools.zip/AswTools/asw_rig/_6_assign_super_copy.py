import bpy

vars = bpy.context.scene.asw_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

list_exceptions = [
    vars.clavicle0_L,
    vars.clavicle1_L,
    vars.clavicle2_L,
    vars.clavicle0_R,
    vars.clavicle1_R,
    vars.clavicle2_R,
]

for b in obj.data.bones:
    if b.name not in list_exceptions and not b.layers[0] and not b.layers[4] and not b.layers[27] and not b.layers[1]: # Hair; Face [Secondary]; Extreme Deform
        continue

    b = obj.pose.bones[b.name]
    if not b.rigify_type: # Else: Rig type already assinged.
        b.rigify_type = "basic.super_copy"
        b.rigify_parameters.super_copy_widget_type = "bone"
        
        if b.parent is None or b.parent.name == 'root': # 4; We changed the name or vars.root.
            b.rigify_parameters.relink_constraints = False
        else:
            b.rigify_parameters.relink_constraints = True
            
            p = "DEF-" + b.parent.name
            b.rigify_parameters.parent_bone = p

print(f"{obj.name}: Assigned super copy rig type to leftovers.")