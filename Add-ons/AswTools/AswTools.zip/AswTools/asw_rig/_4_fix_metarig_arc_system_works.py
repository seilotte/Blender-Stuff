import bpy
from mathutils import Matrix
from math import radians

vars = bpy.context.scene.asw_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

def edit_bone_rotate(angle, axis):
    rotation_matrix = Matrix.Rotation(radians(angle), 4, axis)
    pivot_matrix = Matrix.Translation(b.head) # pivot point
    final_matrix = pivot_matrix @ rotation_matrix @ pivot_matrix.inverted() @ b.matrix
    b.matrix = final_matrix

def swap_head_tail(): # Needs edit mode.
    swap_dict = {
        'lowarm': {'L': 'b.head.x > b.tail.x', 'R': 'b.head.x < b.tail.x'},
        'wrist_': {'L': 'b.head.x > b.tail.x', 'R': 'b.head.x < b.tail.x'},
        'calf': {'L': 'b.head.z < b.tail.z', 'R': 'b.head.z < b.tail.z'}
    }
    side = 'L' if 'L' in b.name else 'R'

    for i, condition in swap_dict.items():
        if i in b.name and side in b.name:
            if eval(condition[side]):
                swap = b.head.xyz
                b.head.xyz = b.tail.xyz
                b.tail.xyz = swap 

#                print(f'SWAPPED: "{b.name}"')

# ===========================

activeMode = obj.mode
bpy.ops.object.mode_set(mode="EDIT") # Edit bones only exist in edit mode.


# Fix twist bones.
ignore_substrings = {
    'muslce', 'scl', 'z', 'belt',
    'G_up', # Strive
#    'GP', # FighterZ
    'wrist_down', 'wrist_up', # Xrd
}

for b in obj.data.edit_bones:
    if b is not None:
        
        # Fix root
        if b.name == vars.root:
            edit_bone_rotate(-90, b.x_axis)
            b.length *= 0.6
            b.name = "root"

        # Fix rotations.
        elif b.name == vars.spine0:
            edit_bone_rotate(180, b.z_axis)
            b.roll = 0
        
        elif b.name in ['G_lowarmup_L', 'G_lowarmup_L_scl']: # Just strive.
            if b.head.z < b.tail.z:
                edit_bone_rotate(-126.422, b.z_axis)
        elif b.name in ['G_lowarmup_R', 'G_lowarmup_R_scl']:
            if b.head.z < b.tail.z:
                edit_bone_rotate(126.422, b.z_axis)
        
        elif b.name in ['G_wrist_L', 'G_wristBand_L', 'G_wrist_down_L', 'G_wrist_up_L', 'G_lowarmlow_L']: # Xrd
            if (b.tail.x - b.head.x) <= .0001: # Greater than with tolerance x.
                edit_bone_rotate(-90, b.z_axis)
        elif b.name in ['G_wrist_R', 'G_wristBand_R', 'G_wrist_down_R', 'G_wrist_up_R', 'G_lowarmlow_R']: # Xrd
            if (b.head.x - b.tail.x) <= .0001:
                edit_bone_rotate(90, b.z_axis)
        
        
        # Fix position.
        # IK's arms/legs
        elif b.name == vars.arm1_L or b.name == vars.arm1_R:
            b.head.y += 0.0003
        elif b.name == vars.leg1_L or b.name == vars.leg1_R:
            b.head.y -= 0.003
        
        # Fix hands.
        elif b.name == vars.arm2_L or b.name == vars.arm2_R:
            b.tail.y = b.head.y
            b.tail.z = b.head.z
            b.length *= 2.0


# Fix future twist bones, for rotation constraints.
for b in obj.data.edit_bones:    
    if vars.arm1_L[2:-2] in b.name or vars.leg1_L[2:-2] in b.name or 'wrist' in b.name: # lowarm; calf
        # Ignore bones.
        if any(i in b.name for i in ignore_substrings):
            continue
        
        if b.layers[27]:
            swap_head_tail()

# ===========================

# Add heel bones.
def heel_bone(name, to_bone_name, R=False):
    toBone = obj.data.bones[to_bone_name]
    newBone = obj.data.edit_bones.new(name)
    if R:
        newBone.head = (-0.06, 0.06, 0.03)
        newBone.tail = (-0.123, 0.06, 0.03)
        newBone.layers = [l == 17 for l in range(32)] # Leg.R IK
    else:
        newBone.head = (0.06, 0.06, 0.03)
        newBone.tail = (0.123, 0.06, 0.03)
        newBone.layers = [l == 14 for l in range(32)] # Leg.L IK
    
    if toBone.parent:
        newBone.parent = obj.data.edit_bones[toBone.parent.name]

heel_bone("G_Heel_L", vars.leg3_L) #TODO: We should check for the last bone on the list.
heel_bone("G_Heel_R", vars.leg3_R, True)


bpy.ops.object.mode_set(mode=activeMode)

print(f"{obj.name}: Fixed arc system works metarig.")