import bpy
import difflib

vars = bpy.context.scene.asw_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

asw_names = [
    'G_mayu_5out_edge', 'G_mayu_4out', 'G_mayu_3mid', 'G_mayu_2in', 'G_mayu_1in_edge', # Eyebrows
    'G_eye',
    'G_eyelid_out', 'G_eyelid_upout', 'G_eyelid_up', 'G_eyelid_upin',
    'G_eyelid_in', 'G_eyelid_lowin', 'G_eyelid_low', 'G_eyelid_lowout',
    'G_ago', 'G_ago_end', # Jaw and chin.
    'G_teeth_up', 'G_teeth_low',
    'G_mouth_Mup', 'G_mouth_upin', 'G_mouth_upout', 'G_mouthside_up_', # Top lips.
    'G_mouth_Mlow', 'G_mouth_lowin', 'G_mouth_lowout', 'G_mouthside_low_', # Bottom lips.
    'G_tongue_tip', 'G_tongue_base',
]

ignore_substrings = [
    'root', 'skirt', 'hair',
    'def', '_z', # Strive
    'GP_', 'GDU_', 'FX_', # FighterZ
#    Similar to Strive. Xrd
    'GDPU_', 'GDP_', 'Root', 'GD_Head', # Dnf_Duel
#    Similar to Strive. Granblue
#    Similar to Strive. Blazeblue
]

# Create bone names list.
all_bone_names = []
for b in obj.data.bones:
    
    # Ignore potentially unwanted strings.
    if any(i in b.name for i in ignore_substrings):
        continue
    
    all_bone_names.append(b.name)
del ignore_substrings

# Search for names.
for i in asw_names:
    best_match = difflib.get_close_matches(i, all_bone_names, 1, 0.5)
    print(f"{best_match}___{i}")

del asw_names


print(f'{obj.name}: Succesfully input names in ASW panel.')