import bpy
from AswTools.rig_utils import custom_strings

vars = bpy.context.scene.asw_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

vars_lists = custom_strings(vars)

def move_bone_layer(list_names, tolayer, add_children=False):
    # Move bone layers.
    if b.name in list_names:
        b.layers = [i == tolayer for i in range(32)] # Disable rest of layers with a list compression.
        
        # Add bone children.
        if add_children and b.children is not None:
            for c in b.children_recursive:
                if len(b.name) == len(c.name):
                    c.layers = [layer == tolayer for layer in range(32)]

# ===========================

for b in obj.data.bones:
    b.layers = [i == 27 for i in range(32)] # Extreme Deform

for b in obj.data.bones: # b = bone
#    b.layers = [i == 27 for i in range(32)] # Childrens get moved since loop.
    
    move_bone_layer(vars.root, 28) # Root
    move_bone_layer(vars_lists['spine'], 5) # Torso [IK]
    
    if b.name == vars.head0 and b.children is not None: # Normally after the neck bone comes the head bone.
        for c in b.children_recursive:
            c.layers = [i == 4 for i in range(32)] # Face [Secondary]
            
            # Check for hair bones.
            if 'hair' in c.name.lower() or 'ponytail' in c.name.lower() or 'bangs' in c.name.lower():
                c.layers = [i == 0 for i in range(32)] # Hair
    
    move_bone_layer(vars_lists['head'], 5)
    move_bone_layer(vars_lists['clavicleL'], 5)
    move_bone_layer(vars_lists['clavicleR'], 5)
    move_bone_layer(vars_lists['armL'], 8) # Arm.L [IK]
    move_bone_layer(vars_lists['armR'], 11) # Arm.R [IK]
    move_bone_layer(vars_lists['legL'], 14) # Leg.L [IK]
    move_bone_layer(vars_lists['legR'], 17) # Leg.R [IK]
    move_bone_layer(vars_lists['fingersL'], 20, True) # Fingers
    move_bone_layer(vars_lists['fingersR'], 20, True)

print(obj.name+": Moved bone layers.")


# Make all layers visible on the metarig.
if obj.type == 'ARMATURE':
    obj.show_in_front = True
    obj.data.layers = [i not in [0, 4] for i in range(32)]
#    for i in range(32):
#        obj.data.layers[i] = True

print(f"{obj.name}: All bone layers are now visible.")