import bpy
import difflib

vars = bpy.context.scene.asw_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

asw_names = [
    'G_pelvis', 'G_waist', 'G_stomach', 'G_chest', 'G_neck', # Spine
    'G_head_att', # Head
    'G_shlder', 'G_clavicle', # Clavicles
    'G_uparm', 'G_oarm', 'GD_Hand_', # Arms
    'G_thigh', 'G_calf', 'G_foot', 'G_toe', # Legs
    'G_fng_a1', 'G_fng_b1', 'G_fng_c1', 'G_fng_d1', 'G_fng_e1', # Fingers
]

ignore_substrings = [
    'root', 'skirt', 'hair',
    'def', '_z', # Strive
    'GP_', 'GDU_', 'FX_', # FighterZ
#    Similar to Strive. Xrd
    'GDPU_', 'GDP_', 'Root', 'GD_Head', # Dnf_Duel
#    Similar to Strive. Granblue
#    Similar to Strive. Blazeblue
]

# Create bone names list.
all_bone_names = []
for b in obj.data.bones:
    
    # Ignore potentially unwanted strings.
    if any(i in b.name for i in ignore_substrings):
        continue
    
    all_bone_names.append(b.name)
del ignore_substrings


vars_list = [
    'spine0', 'spine1', 'spine2', 'spine3', 'spine4',
    'head0',
    'clavicle0_R', 'clavicle1_R',
    'arm0_R', 'arm1_R', 'arm2_R',
    'leg0_R', 'leg1_R', 'leg2_R', 'leg3_R',
    'thumb_R', 'index_R', 'mid_R', 'ring_R', 'pinky_R',
]

x = 0
# Search for names.
for i in asw_names:
    best_match = difflib.get_close_matches(i, all_bone_names, 1, 0.5)
#    print(f"{best_match}___{i}")
    
    if not 'R' in best_match[0]:
        setattr(vars, vars_list[x], best_match[0])
    else:
        setattr(vars, vars_list[x], best_match[0]) # Right
        
        left_string = best_match[0].replace('R', 'L') # Left
        vars_L = vars_list[x].replace('R', 'L')
        setattr(vars, vars_L, left_string)
    
    x += 1

del all_bone_names # I crashed a lot when using difflib, this helped.
del asw_names
del vars_list, x


# Clavicle or shoulder first?
for b in obj.data.bones:
    if b.name == vars.clavicle0_L:
        break
    if b.name == vars.clavicle1_L:
        save_var = vars.clavicle0_L
        vars.clavicle0_L = vars.clavicle1_L
        vars.clavicle1_L = save_var
        
        save_var = vars.clavicle0_R
        vars.clavicle0_R = vars.clavicle1_R
        vars.clavicle1_R = save_var
        break


# TODO: Dnf_duel fingers needs caps in a, b, c, d, e. Think of an easy solution.
if vars.thumb_L == vars.index_L:
    name = 'GD_Fng_E1_L'
    vars.thumb_L = name.replace('E', 'A')
    vars.index_L = name.replace('E', 'B')
    vars.mid_L = name.replace('E', 'C')
    vars.ring_L = name.replace('E', 'D')
    
    name = 'GD_Fng_E1_R'
    vars.thumb_R = name.replace('E', 'A')
    vars.index_R = name.replace('E', 'B')
    vars.mid_R = name.replace('E', 'C')
    vars.ring_R = name.replace('E', 'D')


# Find root bone.
if 'root' in obj.data.bones[0].name or 'Root' in obj.data.bones[0].name:
    vars.root = obj.data.bones[0].name
else:
    vars.root = ''

print(f'{obj.name}: Succesfully changed input names in ASW panel.')