import bpy
from AswTools.rig_utils import custom_strings

vars = bpy.context.scene.asw_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

def rig_type_settings(
                b, # Bone
                rig_type,
                ik_wrist,
                lmb_type,
                fk_lyrs,
                fk_layer,
                twk_lyrs,
                tweak_layer,
                cnt_chain,
                ik_finger,
                ik_lyrs_extra,
                ik_layer_extra,
                custom_finger_orientation,
):

    for i in range(32): # Remove bone layers.
        b.rigify_parameters.fk_layers[i] = False
        b.rigify_parameters.tweak_layers[i] = False
        b.rigify_parameters.extra_ik_layers[i] = False
    b.rigify_type = rig_type
    b.rigify_parameters.make_ik_wrist_pivot = ik_wrist
    b.rigify_parameters.limb_type = lmb_type
    if fk_lyrs:
        b.rigify_parameters.fk_layers[fk_layer] = True
    if twk_lyrs:
        b.rigify_parameters.tweak_layers[tweak_layer] = True
    b.rigify_parameters.connect_chain = cnt_chain
    b.rigify_parameters.make_extra_ik_control = ik_finger
    if ik_lyrs_extra:
        b.rigify_parameters.extra_ik_layers_extra = True
        b.rigify_parameters.extra_ik_layers[ik_layer_extra] = True
    
    # Fingers
    if custom_finger_orientation:
        b.rigify_parameters.primary_rotation_axis = custom_finger_orientation
        if b.name == vars.thumb_L or b.name == vars.thumb_R:
            b.rigify_parameters.primary_rotation_axis = "-X"
    else:
        b.rigify_parameters.primary_rotation_axis = "automatic"


def assign_rigtype(lyr, list_names, group_name="Rig_Type"):    
    # Check for layer and name.
    if bone.layers[lyr] and bone.name in list_names:
        b = obj.pose.bones[bone.name]
        
        if type(list_names) != list:
            rig_type_settings(b, *rigify_map.get(b.name))
        else:
            rig_type_settings(b, *rigify_map.get(list_names[0]))
        
        # Assign the bone group.
        if group_name in obj.pose.bone_groups:
            group = obj.pose.bone_groups.get(group_name)
        else:
            group = obj.pose.bone_groups.new(name=group_name)
            group.color_set = 'CUSTOM'
            group.colors.normal = (0.97, 0.26, 0.57)
            group.colors.select = (0.6, 0.9, 1.0)
            group.colors.active = (0.769, 1.0, 1.0)
        b.bone_group = group

# ===========================

vars_lists = custom_strings(vars)

rigify_map = { # Used in assign_rigtype().
vars.arm0_L: ("limbs.super_limb", True, "arm", True, 9, True, 7, False, False, False, 0, False),
vars.arm0_R: ("limbs.super_limb", True, "arm", True, 12, True, 7, False, False, False, 0, False),
vars.leg0_L: ("limbs.super_limb", False, "leg", True, 15, True, 7, False, False, False, 0, False),
vars.leg0_R: ("limbs.super_limb", False, "leg", True, 18, True, 7, False, False, False, 0, False),
vars.spine0: ("spines.basic_spine", False, "arm", True, 6, True, 7, False, False, False, 0, False),
vars_lists['spine'][-1]: ("spines.super_head", False, "arm", False, 0, True, 7, True, False, False, 0, False),
vars.thumb_L: ("limbs.super_finger", False, "arm", False, 0, True, 22, False, True, True, 21, "-Z"),
vars.thumb_R: ("limbs.super_finger", False, "arm", False, 0, True, 22, False, True, True, 21, "Z")
}

for bone in obj.data.bones:
        
    assign_rigtype(5, vars.spine0) # Torso[IK]
    assign_rigtype(5, vars_lists['spine'][-1])
    assign_rigtype(8, vars.arm0_L) # Arm.L [IK]
    assign_rigtype(11, vars.arm0_R) # Arm.R [IK]
    assign_rigtype(14, vars.leg0_L) # Leg.L [IK]
    assign_rigtype(17, vars.leg0_R) # Leg.R [IK]
    assign_rigtype(20, vars_lists['fingersL']) # Fingers
    assign_rigtype(20, vars_lists['fingersR'])

print(f"{obj.name}: Assigned rig types.")