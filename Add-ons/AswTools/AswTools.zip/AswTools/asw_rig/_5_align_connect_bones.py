import bpy
from AswTools.rig_utils import custom_strings
from mathutils import Matrix
from math import radians

vars = bpy.context.scene.asw_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

def align_bones(list_names, child_only=False):
    # Align bones.
    if b.name in list_names:
        if not child_only:
            if b.parent is not None:
                b.parent.tail.xyz = b.head.xyz
                b.use_connect = True
        
        else:
            if b.children is not None:
                for c in b.children_recursive:
                    if len(c.name) == len(b.name): # Most likely fingers names will have the same length.
                        if c.parent is not None:
                            c.parent.tail.xyz = c.head.xyz
                            c.use_connect = True

# ===========================

vars_lists = custom_strings(vars)

activeMode = obj.mode
bpy.ops.object.mode_set(mode="EDIT") # Edit bones only exist in edit mode.

not_connect = [vars_lists['spine'][-1], vars.arm0_L, vars.arm0_R]

for b in obj.data.edit_bones:
    
    align_bones(vars_lists['spine'][1:])
    align_bones(vars_lists['head'])
    align_bones(vars_lists['clavicleL'][1:])
    align_bones(vars_lists['clavicleR'][1:])
    align_bones(vars_lists['armL'])
    align_bones(vars_lists['armR'])
    align_bones(vars_lists['legL'][1:])
    align_bones(vars_lists['legR'][1:])
    align_bones(vars_lists['fingersL'], True)
    align_bones(vars_lists['fingersR'], True)

    if b.name in not_connect:
        b.use_connect = False


bpy.ops.object.mode_set(mode=activeMode)

print(f"{obj.name}: Aligned and connected bones.")