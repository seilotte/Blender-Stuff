import bpy
from bpy.types import Panel
# av = apex_variables

# Global panel UI properties.
class AswPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ASW'


# Create rigify tools UI panel.
class ASW_PT_RigifyTools(AswPanel, Panel):
    bl_label = 'Rigify Tools'
    bl_idname = 'ASW_PT_rigify_tools'
#    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        if 'rigify' not in context.preferences.addons.keys():
            self.layout.label(text="Rigify addon is not enabled!", icon="ERROR")
#            return
        else:
            col = self.layout.column(align=True)
            col.operator("asw.generate_metarig", text="Generate Metarig", icon="POSE_HLT")
            col.operator("asw.generate_rigify", text="Generate Rig (fixed)", icon="POSE_HLT")
            
        self.layout.separator()
        
        col = self.layout.column(align=True)
        col.label(text="Metarig Bones", icon="GROUP_BONE")
        col.label(text="From Front View [numpad1]", icon="LAYER_USED")
        col.prop(context.scene.asw_variables, 'root', text='')

# Create body bones UI subpanel.
class ASW_PT_BodyBones(AswPanel, Panel):
    bl_label = 'Body Bones'
    bl_idname = 'ASW_PT_body_bones'
    bl_parent_id = 'ASW_PT_rigify_tools'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        pass

# Create face bones UI subpanel.
class ASW_PT_FaceBones(AswPanel, Panel):
    bl_label = 'Face Bones'
    bl_idname = 'ASW_PT_face_bones'
    bl_parent_id = 'ASW_PT_rigify_tools'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        pass


# =========================== Body Bones UI.

# Create columns with an icon.
def asw_row(col, prop_name, prop_text="", row_icon="BLANK1"):
    av = bpy.context.scene.asw_variables
    
    row = col.row(align=True)
    row.label(icon=row_icon)
    row.prop(av, prop_name, text=prop_text)

def asw_row_list(col, my_list, start_name=True, end_name=True):
    av = bpy.context.scene.asw_variables
    
    # Count the strings that are not empty.
    last_string_element = -1 # Last element with a string.
    for c in my_list:
        if hasattr(av, c) and getattr(av, c) != "":
            last_string_element += 1

    for i, item in enumerate(my_list): # Enumerate() gets the index(i) and the "string"(item) of the list.
        if hasattr(av, item) and getattr(av, item) != "":
            if i == 0 and start_name: # first_element
                asw_row(col, item, "Start ", "DISCLOSURE_TRI_RIGHT")
            elif i == last_string_element and end_name:
                asw_row(col, item, "End ", "DISCLOSURE_TRI_RIGHT")
            else:
                asw_row(col, item, " ")
        else:
            asw_row(col, item, "Add? ")
            break



# Create spine bones UI subpanel.
class ASW_PT_SpineBones(AswPanel, Panel):
    bl_label = 'Spine Bones'
#    bl_idname = 'ASW_PT_spine_bones'
    bl_parent_id = 'ASW_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        col.label(text="Bottom → Top", icon="LAYER_USED")
        asw_row_list(col, av.spine_list)

# Create head bones UI subpanel.
class ASW_PT_HeadBones(AswPanel, Panel):
    bl_label = 'Head Bones'
#    bl_idname = 'ASW_PT_head_bones'
    bl_parent_id = 'ASW_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        e = -1 # Last element with a string.
        for i in av.spine_list:
            if hasattr(av, i) and getattr(av, i) != "":
                e += 1
        
        #UI
        col.label(text="Bottom → Top", icon="LAYER_USED")
        if e > 0:
            asw_row(col, av.spine_list[e], "Start", "DISCLOSURE_TRI_RIGHT")
        asw_row_list(col, av.head_list, start_name=False)

# Create clavicles bones UI subpanel.
class ASW_PT_ClaviclesBones(AswPanel, Panel):
    bl_label = 'Clavicles Bones'
#    bl_idname = 'ASW_PT_clavicles_bones'
    bl_parent_id = 'ASW_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        col.label(text="Left → Right", icon="LAYER_USED")
        col.label(text="Left", icon="BONE_DATA")
        asw_row_list(col, av.clavicleL_list)
        
        col.separator(factor=3.0)
        
        col.label(text="Right → Left", icon="LAYER_USED")
        col.label(text="Right", icon="BONE_DATA")
        asw_row_list(col, av.clavicleR_list)

# Create arms bones UI subpanel.
class ASW_PT_ArmsBones(AswPanel, Panel):
    bl_label = 'Arms Bones'
#    bl_idname = 'ASW_PT_arms_bones'
    bl_parent_id = 'ASW_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        col.label(text="Left → Right", icon="LAYER_USED")
        col.label(text="Left", icon="BONE_DATA")
        asw_row(col, "arm0_L", "Start", "DISCLOSURE_TRI_RIGHT")
        asw_row(col, "arm1_L", " ")
        asw_row(col, "arm2_L", "End", "DISCLOSURE_TRI_RIGHT")
        
        col.separator(factor=3.0)
        
        col.label(text="Right → Left", icon="LAYER_USED")
        col.label(text="Right", icon="BONE_DATA")
        asw_row(col, "arm0_R", "Start", "DISCLOSURE_TRI_RIGHT")
        asw_row(col, "arm1_R", " ")
        asw_row(col, "arm2_R", "End", "DISCLOSURE_TRI_RIGHT")

# Create legs bones UI subpanel.
class ASW_PT_LegsBones(AswPanel, Panel):
    bl_label = 'Legs Bones'
#    bl_idname = 'ASW_PT_legs_bones'
    bl_parent_id = 'ASW_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        col.label(text="Top → Bottom", icon="LAYER_USED")
        col.label(text="Left", icon="BONE_DATA")
        asw_row_list(col, av.legL_list)
        
        col.separator(factor=3.0)
        
        col.label(text="Top → Bottom", icon="LAYER_USED")
        col.label(text="Right", icon="BONE_DATA")
        asw_row_list(col, av.legR_list)

# Create fingers bones UI subpanel.
class ASW_PT_FingersBones(AswPanel, Panel):
    bl_label = 'Fingers Bones'
#    bl_idname = 'ASW_PT_finger_bones'
    bl_parent_id = 'ASW_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        # User Interface.
        col.label(text="Left", icon="BONE_DATA")
        for i in av.fingersL_list:
            col.prop(av, i)
        
        col.separator(factor=3.0)
        
        col.label(text="Right", icon="BONE_DATA")
        for i in av.fingersR_list:
            col.prop(av, i)

# =========================== Face Bones UI.

# Create eyebrows bones UI subpanel.
class ASW_PT_EyebrowsBones(AswPanel, Panel):
    bl_label = 'Eyebrows Bones'
#    bl_idname = 'ASW_PT_eyebrows_bones'
    bl_parent_id = 'ASW_PT_face_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        col.label(text="Right → Left", icon="LAYER_USED")
        col.label(text="Left", icon="BONE_DATA")
        asw_row_list(col, av.eyebrowL_list)
        
        col.separator(factor=3.0)
        
        col.label(text="Left → Right", icon="LAYER_USED")
        col.label(text="Right", icon="BONE_DATA")
        asw_row_list(col, av.eyebrowR_list)

# Create left eye bones UI subpanel.
class ASW_PT_LeftEyeBones(AswPanel, Panel):
    bl_label = 'Left Eye Bones'
#    bl_idname = 'ASW_PT_left_eye_bones'
    bl_parent_id = 'ASW_PT_face_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "eye_L", text="Eye")
        
        col.separator(factor=3.0)
        
        col.label(text="Right → Left", icon="LAYER_USED")
        col.label(text="Top", icon="BONE_DATA")
        asw_row_list(col, av.eyeTL_list)
        col.separator(factor=3.0)
        col.label(text="Left → Right", icon="LAYER_USED")
        col.label(text="Bottom", icon="BONE_DATA")
        asw_row_list(col, av.eyeBL_list)

# Create right eye bones UI subpanel.
class ASW_PT_RightEyeBones(AswPanel, Panel):
    bl_label = 'Right Eye Bones'
#    bl_idname = 'ASW_PT_right_eye_bones'
    bl_parent_id = 'ASW_PT_face_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "eye_R", text="Eye")
        
        col.separator(factor=3.0)
        
        col.label(text="Left → Right", icon="LAYER_USED")
        col.label(text="Top", icon="BONE_DATA")
        asw_row_list(col, av.eyeTR_list)
        col.separator(factor=3.0)
        col.label(text="Right → Left", icon="LAYER_USED")
        col.label(text="Bottom", icon="BONE_DATA")
        asw_row_list(col, av.eyeBR_list)

# =========================== Mouth Bones UI.

# Create mouth bones UI subpanel.
class ASW_PT_MouthBones(AswPanel, Panel):
    bl_label= 'Mouth Bones'
    bl_idname = 'ASW_PT_mouth_bones'
    bl_parent_id = 'ASW_PT_face_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True)
        
        #UI.
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "jaw")
        
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "chin")
        
        col.separator()
        
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "teeth_T")
        
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "teeth_B")

# Create lips bones UI subpanel.
class ASW_PT_LeftLipsBones(AswPanel, Panel):
    bl_label = 'Left Lips Bones'
#    bl_idname = 'ASW_PT_left_lips_bones'
    bl_parent_id = 'ASW_PT_mouth_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        f = -1 # Last element with a string.
        for i  in av.lipTL_list:
            if hasattr(av, i) and getattr(av, i) != "":
                f += 1
        
        # UI.
        col.label(text="Middle → Right", icon="LAYER_USED")
        col.label(text="Top", icon="BONE_DATA")
        row = col.row(align=True) # Icon + row.
        row.label(icon="DISCLOSURE_TRI_RIGHT")
        row.prop(av, "lip_C_T", text="Start") # Center top.
        
        asw_row_list(col, av.lipTL_list, False) # Disable start.
        
        col.separator(factor=3.0)
        
        col.label(text="Middle → Right", icon="LAYER_USED")
        col.label(text="Bottom", icon="BONE_DATA")
        row = col.row(align=True) # Icon + row.
        row.label(icon="DISCLOSURE_TRI_RIGHT")
        row.prop(av, "lip_C_B", text="Start") # Center bottom.
        
        asw_row_list(col, av.lipBL_list, False, False) # Disable start and end.
        if f > 0:
            asw_row(col, av.lipTL_list[f], "End", "DISCLOSURE_TRI_RIGHT")

# Create lips bones UI subpanel.
class ASW_PT_RightLipsBones(AswPanel, Panel):
    bl_label = 'Right Lips Bones'
#    bl_idname = 'ASW_PT_right_lips_bones'
    bl_parent_id = 'ASW_PT_mouth_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align=True) # Main column.
        
        g = -1 # Last element with a string.
        for i in av.lipTR_list:
            if hasattr(av, i) and getattr(av, i) != "":
                g += 1
        
        #UI
        col.label(text="Middle → Left", icon="LAYER_USED")
        col.label(text="Top", icon="BONE_DATA")
        row = col.row(align=True) # Icon + row.
        row.label(icon="DISCLOSURE_TRI_RIGHT")
        row.prop(av, "lip_C_T", text="Start") # Center top.
        
        asw_row_list(col, av.lipTR_list, False) # Disable start.
        
        col.separator(factor=3.0)
        
        col.label(text="Middle → Left", icon="LAYER_USED")
        col.label(text="Bottom", icon="BONE_DATA")
        row = col.row(align=True) # Icon + row.
        row.label(icon="DISCLOSURE_TRI_RIGHT")
        row.prop(av, "lip_C_B", text="Start") # Center bottom.
        
        asw_row_list(col, av.lipBR_list, False, False) # Disable start and end.
        if g > 0:
            asw_row(col, av.lipTR_list[g], "End", "DISCLOSURE_TRI_RIGHT")

# Create tongue bones UI subpanel.
class ASW_PT_TongueBones(AswPanel, Panel):
    bl_label = 'Tongue Bones'
#    bl_idname = 'ASW_PT_tongue_bones'
    bl_parent_id = 'ASW_PT_mouth_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.asw_variables
        col = self.layout.column(align = True) # Main column.
        
        #UI.
        col.label(text="Tip → End", icon="LAYER_USED")
        asw_row_list(col, av.tongue_list)

# ===========================

classes = [
    ASW_PT_RigifyTools,
    ASW_PT_BodyBones,
    ASW_PT_FaceBones,
    
    ASW_PT_SpineBones,
    ASW_PT_HeadBones,
    ASW_PT_ClaviclesBones,
    ASW_PT_ArmsBones,
    ASW_PT_LegsBones,
    ASW_PT_FingersBones,
    
    ASW_PT_EyebrowsBones,
    ASW_PT_LeftEyeBones,
    ASW_PT_RightEyeBones,
    
    ASW_PT_MouthBones,
    ASW_PT_LeftLipsBones,
    ASW_PT_RightLipsBones,
    ASW_PT_TongueBones,
]
def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)