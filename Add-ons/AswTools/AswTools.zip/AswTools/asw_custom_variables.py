import bpy
#from bpy.props import EnumProperty, IntProperty, FloatProperty, PointerProperty, BoolProperty, StringProperty
from bpy.props import StringProperty, PointerProperty, BoolProperty

# Create custom variables.
class Asw_Variables(bpy.types.PropertyGroup):

    # Mesh Tools
    outline_sharp_edges: BoolProperty(name='Sharp Edges?', description='Use sharp edges on the outline mesh')

    # Nodes Data
    from_armature: PointerProperty(name='FromArmature', type=bpy.types.Object)
    dir: StringProperty(name='Folder Path', subtype='DIR_PATH', description='Path to the folder containing the images')

    # Rigify Tools
# =========================== Metarig bones.

    # Root
    root: StringProperty(name='Root', default='G_body_root')
    
    # Spine bones.
    # TODO: Use blender CollectionProperty instead of lists and create them procedurally.
    spine_list = ['spine0', 'spine1', 'spine2', 'spine3', 'spine4', 'spine5', 'spine6']

    spine0: StringProperty(name='Spine Start', default='G_pelvis') # Start
    spine1: StringProperty(name='Spine1', default='G_waist') # Inbetweens
    spine2: StringProperty(name='Spine2', default='G_stomach')
    spine3: StringProperty(name='Spine3', default='G_chest')
    spine4: StringProperty(name='Spine4', default='G_neck')
    spine5: StringProperty(name='Spine5')
    spine6: StringProperty(name='Spine6')
    
    # Head bones.
    head_list = ['head0', 'head1', 'head2']
    
    head0: StringProperty(name='Head0', default='G_Head_Attach') # Last spine element is the start.
    head1: StringProperty(name='Head1')
    head2: StringProperty(name='Head2')
    
    
    # Left clavicles bones.
    clavicleL_list = ['clavicle0_L', 'clavicle1_L', 'clavicle2_L']
    
    clavicle0_L: StringProperty(name='Left Clavicle Start', default='G_shoulder_L') # Start
    clavicle1_L: StringProperty(name='Left Clavicle1', default='G_clavicle_L')
    clavicle2_L: StringProperty(name='Left Clavicle2')
    
    # Right clavicles bones.
    clavicleR_list = ['clavicle0_R', 'clavicle1_R', 'clavicle2_R']
    
    clavicle0_R: StringProperty(name='Right Clavicle Start', default='G_shoulder_R') # Start
    clavicle1_R: StringProperty(name='Right Clavicle1', default='G_clavicle_R')
    clavicle2_R: StringProperty(name='Right Clavicle2')
    
    
    # Left arm bones.
    armL_list = ['arm0_L', 'arm1_L', 'arm2_L']
    
    arm0_L: StringProperty(name='Left Arm Start', default='G_uparm_L') # Start
    arm1_L: StringProperty(name='Left Arm Mid', default='G_lowarm_L') # Inbetween
    arm2_L: StringProperty(name='Left Arm End', default='G_hand_L') # End
    
    # Right arm bones.
    armR_list = ['arm0_R', 'arm1_R', 'arm2_R']
    
    arm0_R: StringProperty(name='Right Arm Start', default='G_uparm_R') # Start
    arm1_R: StringProperty(name='Right Arm Mid', default='G_lowarm_R') # Inbetween
    arm2_R: StringProperty(name='Right Arm End', default='G_hand_R') # End
    
    
    # Left leg bones.
    legL_list = ['leg0_L', 'leg1_L', 'leg2_L', 'leg3_L', 'leg4_L', 'leg5_L']
    
    leg0_L: StringProperty(name='Left Leg Start', default='G_thigh_L') # Start
    leg1_L: StringProperty(name='Left Leg1', default='G_calf_L') # Inbetween
    leg2_L: StringProperty(name='Left Leg2', default='G_foot_L')
    leg3_L: StringProperty(name='Left Leg3', default='G_toe_L')
    leg4_L: StringProperty(name='Left Leg4')
    leg5_L: StringProperty(name='Left Leg5') # Why you have four and five?
    
    # Right leg bones.
    legR_list = ['leg0_R', 'leg1_R', 'leg2_R', 'leg3_R', 'leg4_R', 'leg5_R']
    
    leg0_R: StringProperty(name='Right Leg Start', default='G_thigh_R') # Start
    leg1_R: StringProperty(name='Right Leg1', default='G_calf_R') # Inbetween
    leg2_R: StringProperty(name='Right Leg2', default='G_foot_R')
    leg3_R: StringProperty(name='Right Leg3', default='G_toe_R')
    leg4_R: StringProperty(name='Right Leg4')
    leg5_R: StringProperty(name='Right Leg5')
    
    
    # Left fingers bones.
    fingersL_list = ['thumb_L', 'index_L', 'mid_L', 'ring_L', 'pinky_L']
    
    thumb_L: StringProperty(name='Left Thumb', default='G_fng_L_a1_')
    index_L: StringProperty(name='Left Index', default='G_fng_L_b1_')
    mid_L: StringProperty(name='Left Middle', default='G_fng_L_c1_')
    ring_L: StringProperty(name='Left Ring', default='G_fng_L_d1_')
    pinky_L: StringProperty(name='Left Pinky', default='G_fng_L_e1_')
    
    # Right fingers bones.
    fingersR_list = ['thumb_R', 'index_R', 'mid_R', 'ring_R', 'pinky_R']
    
    thumb_R: StringProperty(name='Right Thumb', default='G_fng_R_a1_')
    index_R: StringProperty(name='Right Index', default='G_fng_R_b1_')
    mid_R: StringProperty(name='Right Middle', default='G_fng_R_c1_')
    ring_R: StringProperty(name='Right Ring', default='G_fng_R_d1_')
    pinky_R: StringProperty(name='Right Pinky', default='G_fng_R_e1_')

# =========================== Brows and eyes bones.

    # Left eyebrows.
    eyebrowL_list = ['eyebrow0_L', 'eyebrow1_L', 'eyebrow2_L', 'eyebrow3_L', 'eyebrow4_L', 'eyebrow5_L']
    
    eyebrow0_L: StringProperty(name='Left Eyebrow Start', default='G_mayu_Lout_edge')
    eyebrow1_L: StringProperty(name='Left Eyebrow 1', default='G_mayu_Lout')
    eyebrow2_L: StringProperty(name='Left Eyebrow 2', default='G_mayu_Lmid')
    eyebrow3_L: StringProperty(name='Left Eyebrow 3', default='G_mayu_Lin')
    eyebrow4_L: StringProperty(name='Left Eyebrow 4', default='G_mayu_Lin_edge')
    eyebrow5_L: StringProperty(name='Left Eyebrow 5')
    
    # Right eyebrows.
    eyebrowR_list = ['eyebrow0_R', 'eyebrow1_R', 'eyebrow2_R', 'eyebrow3_R', 'eyebrow4_R', 'eyebrow5_R']
    
    eyebrow0_R: StringProperty(name='Right Eyebrow Start', default='G_mayu_Rout_edge')
    eyebrow1_R: StringProperty(name='Right Eyebrow 1', default='G_mayu_Rout')
    eyebrow2_R: StringProperty(name='Right Eyebrow 2', default='G_mayu_Rmid')
    eyebrow3_R: StringProperty(name='Right Eyebrow 3', default='G_mayu_Rin')
    eyebrow4_R: StringProperty(name='Right Eyebrow 4', default='G_mayu_Rin_edge')
    eyebrow5_R: StringProperty(name='Right Eyebrow 5')
    
    
    # Left eye bones.
    eye_L: StringProperty(name='Left Eye', default='G_eye_L')
    eyeTL_list = ['eye0_T_L', 'eye1_T_L', 'eye2_T_L', 'eye3_T_L', 'eye4_T_L']
    
    eye0_T_L: StringProperty(name='Left Upper Eye Start', default='G_eyelid_Lout')
    eye1_T_L: StringProperty(name='Left Upper Eye 1', default='G_eyelid_Lupout')
    eye2_T_L: StringProperty(name='Left Upper Eye 2', default='G_eyelid_Lup')
    eye3_T_L: StringProperty(name='Left Upper Eye 3', default='G_eyelid_Lupin')
    eye4_T_L: StringProperty(name='Left Upper Eye 4')
    
    eyeBL_list = ['eye0_B_L', 'eye1_B_L', 'eye2_B_L', 'eye3_B_L', 'eye4_B_L']
    
    eye0_B_L: StringProperty(name='Left Bottom Eye Start', default='G_eyelid_Lin')
    eye1_B_L: StringProperty(name='Left Bottom Eye 1', default='G_eyelid_Llowin')
    eye2_B_L: StringProperty(name='Left Bottom Eye 2', default='G_eyelid_Llow')
    eye3_B_L: StringProperty(name='Left Bottom Eye 3', default='G_eyelid_Llowout')
    eye4_B_L: StringProperty(name='Left Bottom Eye 4')
    
    # Right eye bones.
    eye_R: StringProperty(name='Right Eye', default='G_eye_R')
    eyeTR_list = ['eye0_T_R', 'eye1_T_R', 'eye2_T_R', 'eye3_T_R', 'eye4_T_R']
    
    eye0_T_R: StringProperty(name='Right Upper Eye Start', default='G_eyelid_Rout')
    eye1_T_R: StringProperty(name='Right Upper Eye 1', default='G_eyelid_Rupout')
    eye2_T_R: StringProperty(name='Right Upper Eye 2', default='G_eyelid_Rup')
    eye3_T_R: StringProperty(name='Right Upper Eye 3', default='G_eyelid_Rupin')
    eye4_T_R: StringProperty(name='Right Upper Eye 4')
    
    eyeBR_list = ['eye0_B_R', 'eye1_B_R', 'eye2_B_R', 'eye3_B_R', 'eye4_B_R']
    
    eye0_B_R: StringProperty(name='Right Bottom Eye Start', default='G_eyelid_Rin')
    eye1_B_R: StringProperty(name='Right Bottom Eye 1', default='G_eyelid_Rlowin')
    eye2_B_R: StringProperty(name='Right Bottom Eye 2', default='G_eyelid_Rlow')
    eye3_B_R: StringProperty(name='Right Bottom Eye 3', default='G_eyelid_Rlowout')
    eye4_B_R: StringProperty(name='Right Bottom Eye 4')
    
# =========================== Mouth bones.
    
    # Jaw and chin bone.
    jaw: StringProperty(name='Jaw', default='G_ago')
    chin: StringProperty(name='Chin', default='G_ago_end')
    teeth_T: StringProperty(name='Upper Teeth', default='G_teeth_up')
    teeth_B: StringProperty(name='Bottom Teeth', default='G_teeth_low')
    
    
    # Lip bones.
    # Center lip bones.
    lip_C_T: StringProperty(name='Center Top Lip', default='G_mouth_Mup') # C = Center
    lip_C_B: StringProperty(name='Center Bottom Lip', default='G_mouth_Mlow')
    
#    lip_list = ['lip0_T_L', 'lip1_T_L', 'lip2_T_L', 'lip3_T_L', 'lip0_B_L', 'lip1_B_L', 'lip2_B_L', 'lip3_B_L', 'lip0_T_R', 'lip1_T_R', 'lip2_T_R', 'lip3_T_R', 'lip0_B_R', 'lip1_B_R', 'lip2_B_R', 'lip3_B_R']
    lipTL_list = ['lip0_T_L', 'lip1_T_L', 'lip2_T_L', 'lip3_T_L', 'lip4_T_L']
    
    lip0_T_L: StringProperty(name='Left Upper Lip Start', default='G_mouth_Lupin')
    lip1_T_L: StringProperty(name='Left Upper Lip 1', default='G_mouth_Lupout')
    lip2_T_L: StringProperty(name='Left Upper Lip 2', default='G_mouthside_up_L')
    lip3_T_L: StringProperty(name='Left Upper Lip 3')
    lip4_T_L: StringProperty(name='Left Upper Lip 4') # Corner is the last bone on the top list.
    
    lipBL_list = ['lip0_B_L', 'lip1_B_L', 'lip2_B_L', 'lip3_B_L']
    
    lip0_B_L: StringProperty(name='Left Bottom Lip Start', default='G_mouth_Llowin')
    lip1_B_L: StringProperty(name='Left Bottom Lip 1', default='G_mouth_Llowout')
    lip2_B_L: StringProperty(name='Left Bottom Lip 2', default='G_mouthside_low_L')
    lip3_B_L: StringProperty(name='Left Bottom Lip 3')
    
    lipTR_list = ['lip0_T_R', 'lip1_T_R', 'lip2_T_R', 'lip3_T_R', 'lip4_T_R']
    
    lip0_T_R: StringProperty(name='Right Upper Lip Start', default='G_mouth_Rupin')
    lip1_T_R: StringProperty(name='Right Upper Lip 1', default='G_mouth_Rupout')
    lip2_T_R: StringProperty(name='Right Upper Lip 2', default='G_mouthside_up_R')
    lip3_T_R: StringProperty(name='Right Upper Lip 3')
    lip4_T_R: StringProperty(name='Right Upper Lip 4') # Corner is the last bone on the top list.
    
    lipBR_list = ['lip0_B_R', 'lip1_B_R', 'lip2_B_R', 'lip3_B_R']
    
    lip0_B_R: StringProperty(name='Right Bottom Lip Start', default='G_mouth_Rlowin')
    lip1_B_R: StringProperty(name='Right Bottom Lip 1', default='G_mouth_Rlowout')
    lip2_B_R: StringProperty(name='Right Bottom Lip 2', default='G_mouthside_low_R')
    lip3_B_R: StringProperty(name='Right Bottom Lip 3')
    
    
    # Tongue bones.
    tongue_list = ['tongue0', 'tongue1', 'tongue2', 'tongue3', 'tongue4']
    
    tongue0: StringProperty(name='Tongue Start', default='G_tongue_tip')
    tongue1: StringProperty(name='Tongue 1', default='G_tongue_base')
    tongue2: StringProperty(name='Tongue 2')
    tongue3: StringProperty(name='Tongue 3')
    tongue4: StringProperty(name='Tongue 4')

# ===========================

def register():
    bpy.utils.register_class(Asw_Variables)
    bpy.types.Scene.asw_variables = bpy.props.PointerProperty(type=Asw_Variables)

def unregister():
    bpy.utils.unregister_class(Asw_Variables)
    del bpy.types.Scene.asw_variables