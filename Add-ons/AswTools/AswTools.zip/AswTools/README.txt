# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 3 of the License.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

## Where to find me

- https://twitter.com/seilotte
    - Note: I don't know how to code.
    - If the code is bad it's thanks to me, not them.

## CREDITS

- Aerthas Veras
	- https://twitter.com/aerthasveras
	- A lot of scripts are based on his.
	- 0initiate_rigify.py is mostly from him.

--------- Addon GUIDE ---------
## Comments

- I used blender 3.4.1, shader should work in lower blender versions.
- The buttons have descriptions.

- IMPORTANT MESSAGE
    - I only tested it on .cast files.
    - I tested: wattson, horizon, bloodhound, pathfinder, loba, valk.
        - Note that pathfinder and valk were broken. But in theory the rig generated correctly.

## Limitations

- Autotexture won't modify the materials if it does not find all the textures.
- The respective bones needs to be placed in the ui.
- A lot of errors might pop-up if it doesn't find certain bones.
- I hardcoded a lot of stuff. Therefore, it won't work in other rigs. You would need to adapt the rig scripts
by deleteting the 3fix_metarig_apex_legends.py, a0fix_face_metarig_apex_legends.py and reading the
check_for_apex_modifications on py.txt.


## Addon guide

- Assign Armature
    - Adds an armature modifier if it doesn't exist, and assigns the selected rig to the modifier.
If it's a rigify rig, it will add DEF- to the vertex groups.
If not it will remove DEF- from the vertex groups.

- Add Cameras
    - Adds a camera to the respective apex camera bone if it exists. I used constraints instead of parenting.

- Fix Rotation & Scale
    - On the selected objects.
Rotates by 90 degrees and scales by 0.254. Applies the transformations.
I think animations should work even with this.

- Rename Objects
    - Renames the selected objects with it's material name.

- Purge
    - Same as blender. Outliner -> Display Mode(Orphan Data) -> Purge 

- Auto Texture
    - If the path is None(""), it will try to look for the images inside the material image node path.
    - If it the image node does not have a path, it will print "missing texture".
    
    - If the path is set, it will search for the images in it.
    
    - AO Node?
        - It will add the ambient occlusion node to the material shader.
    
    - Note: I don't know what will happen if you have multiple recolours/skins in the folder.


- Generate Metarig
    - Poorly tries to fix the metarig based on the input bones.
    - Note: There's apex scripts for this specific rigs.
    
    - If a jaw bone exists it will try to generate a really cheap face rig.

- Generate Rig:
    - Generates the rigify rig, with fixes like moving some bone layers and adding rotation constraints to specified bones.


--------- To do list ---------
## To do

- User interface
    - In rigify_tools, find a way to generate variables. Not just hardcode them in the custom_variables file.
    - Add button that attempts to find the respective bone names.

- Auto texture
    - Make the code better and cleaner.
    - Add a smarter system for generating the eyes materials.
    - Make it search in the sub-folders.
    
    - If a .h file is found in the directories. Assign the respective settings.
You can get the .h file with Legion+.
    - Add uv distortion, iridescence, effects in general.

-Rig
    - Make the code better and cleaner.
    - Add consistency to the code.
    - Use a smarter system for for-loop instead of blender.bones.get().
    - Maybe add a system for swap bones (like tongue) and indicate which twist bones.

- Rig operators
    - Search for the files inside the directory, not hardcoding the path. ".../apex_rig/"


--------- Changelog ---------
- v 1.0
    - Created the addon.
    - It was an "alpha".

- v 1.1
    - Rewrote:
        - README.txt
        - apex_ui_rigify.py to apex_ui_rigify_tools.py
        - apex_ot_rigify.py to apex_ot_generate_metarig.py
        - apex_ot_fixrig.py to apex_ot_generate_rigify.py

        - All inside the "apex_rig" folder.

    - Changed:
        - __init__.py
            - Fixed for new .py names.
            - apex_panel.py got disabled.

        - apex_custom_variables.py
            - Bone variables got rewritten.