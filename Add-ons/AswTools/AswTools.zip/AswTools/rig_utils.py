def custom_strings(vars):
    vars_lists = {}
    custom_lists = {
        'spine': vars.spine_list,
        'head': vars.head_list,
        'clavicleL': vars.clavicleL_list,
        'clavicleR': vars.clavicleR_list,
        'armL': vars.armL_list,
        'armR': vars.armR_list,
        'legL': vars.legL_list,
        'legR': vars.legR_list,
        'fingersL': vars.fingersL_list,
        'fingersR': vars.fingersR_list,
        
        'eyebrowL': vars.eyebrowL_list,
        'eyebrowR': vars.eyebrowR_list,
        'eyeTL': vars.eyeTL_list,
        'eyeBL': vars.eyeBL_list,
        'eyeTR': vars.eyeTR_list,
        'eyeBR': vars.eyeBR_list,
        
        'lipTL': vars.lipTL_list,
        'lipBL': vars.lipBL_list,
        'lipTR': vars.lipTR_list,
        'lipBL': vars.lipBR_list,
        'tongue': vars.tongue_list,
    } # Get custom strings from lists.
    for lst_name, lst in custom_lists.items():
        vars_lists[lst_name] = [getattr(vars, i, None) for i in lst if getattr(vars, i, None)]

    return vars_lists