# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name": "AswTools",
    "author": "Seilotte",
    "version": (0, 0),
    "blender": (3, 4, 1),
    "location": "View3D > Properties > ASW",
    "description": "Random collection of tools for Arc System Works games.",
    "category": "3D View"
}
    
import importlib

#from . import asw_panel
from . import asw_custom_variables
from . import asw_ui_mesh_tools
from . import asw_ui_data_tools
from . import asw_ui_rigify_tools
from . import asw_ot_generate_outlines
from . import asw_ot_assign_rig
from . import asw_ot_fix_mesh_and_mats
from . import asw_ot_autotexture
from . import asw_ot_generate_metarig
from . import asw_ot_generate_rigify


# Each module is expected to have a register() and unregister() function.
modules = [
#    asw_panel,
    asw_custom_variables,
    asw_ui_mesh_tools,
    asw_ui_data_tools,
    asw_ui_rigify_tools,
    asw_ot_generate_outlines,
    asw_ot_assign_rig,
    asw_ot_fix_mesh_and_mats,
    asw_ot_autotexture,
    asw_ot_generate_metarig,
    asw_ot_generate_rigify,
]

def register():
    for m in modules:
        importlib.reload(m)
        try:
            m.register()
        except:
            pass

def unregister():
    for m in modules:
        m.unregister()