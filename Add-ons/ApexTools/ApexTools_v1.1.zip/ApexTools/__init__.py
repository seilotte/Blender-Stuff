# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name": "ApexTools",
    "author": "Seilotte",
    "version": (1, 1),
    "blender": (3, 4, 1),
    "location": "View3D > Properties > Apex",
    "description": "Random collection of tools for Apex Legends.",
    "category": "3D View"
}
    
import importlib

#from . import apex_panel
from . import apex_custom_variables
from . import apex_ui_data_tools
from . import apex_ui_rigify_tools
from . import apex_ot_autotex
from . import apex_ot_assign_rig
from . import apex_ot_generate_metarig
from . import apex_ot_generate_rigify

# Each module is expected to have a register() and unregister() function.
modules = [
#    apex_panel,
    apex_custom_variables,
    apex_ui_data_tools,
    apex_ui_rigify_tools,
    apex_ot_autotex,
    apex_ot_assign_rig,
    apex_ot_generate_metarig,
    apex_ot_generate_rigify,
]

def register():
    for m in modules:
        importlib.reload(m)
        try:
            m.register()
        except:
            pass

def unregister():
    for m in modules:
        m.unregister()