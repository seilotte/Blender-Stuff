import bpy
import os

# Generate rig.
# Fix rigify bone layers and groups.
# Add twist bones constraints.
# Add DEF- to vertex groups names.

class APEX_OT_GenerateRigify(bpy.types.Operator):
    bl_label = "Generate Apex Rigify Rig"
    bl_idname = "apex.generate_rigify"
    bl_description = "Generates a rigify rig from the active apex metarig."
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(self, context):
        if not context.object:
            return False
        return context.object.type == 'ARMATURE'
    
    def execute(self, context):

        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/7generate_fix_rig.py")
        
        # Face check.
        for b in context.view_layer.objects.active.data.bones:
            if b.layers[2]:
                bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/7generate_fix_face_rig.py")
                break
        
        self.report({'INFO'}, 'Succesfully generated: "apex_legends rig"')

        return {'FINISHED'}

# ===========================

def register():
    bpy.utils.register_class(APEX_OT_GenerateRigify)

def unregister():
    bpy.utils.unregister_class(APEX_OT_GenerateRigify)