import bpy

av = bpy.context.scene.apex_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

def move_bone_layer(bone_names, tolayer, lst=True, add_children=False):
    # Access strings of the list with a list compression.
    if lst:
        bone_names = [getattr(av, i) for i in bone_names if hasattr(av, i) and getattr(av, i) != ""]
    
    # Move bone layers.
#    for b in obj.data.bones:
#        if b is not None:
    if b.name in bone_names:
        b.layers = [layer == tolayer for layer in range(32)] # Disable rest of layers with a list compression.
        
        # Add bone children.
        if add_children and b.children is not None:
            for c in b.children_recursive:
                if len(b.name) == len(c.name):
                    c.layers = [layer == tolayer for layer in range(32)]

# ===========================

for b in obj.data.bones: # I don't know why childrens get moved.
    if b is not None: #  I hope it's a temporary fix.
        b.layers = [i == 27 for i in range(32)]

for b in obj.data.bones:
    if b is not None:
#        b.layers[27] = True # First move all bones to Extreme Deform layer.
#        b.layers = [layer == 27 for layer in range(32)] # Disable on other layers.
    
        move_bone_layer(av.root, 28, False) # Root
        move_bone_layer(av.spine_list, 5) # Torso IK
        
        if b.name == av.head0 and b.children is not None: # Normally after the neck bone, there's the head bone.
            for c in b.children_recursive:
                c.layers = [i == 4 for i in range(32)] # Face Secondary
                
                # Check for hair bones in the head children bones.
                if "hair" in c.name.lower() or "ponytail" in c.name.lower() or "bangs" in c.name.lower():
                    c.layers = [i == 0 for i in range(32)] # Hair
        
        move_bone_layer(av.head_list, 5)
        move_bone_layer(av.clavicleL_list, 5)
        move_bone_layer(av.clavicleR_list, 5)
        move_bone_layer(av.armL_list, 8) # Arm.L IK
        move_bone_layer(av.armR_list, 11) # Arm.R IK
        move_bone_layer(av.legL_list, 14) # Leg.L IK
        move_bone_layer(av.legR_list, 17) # Leg.L IK
        move_bone_layer(av.fingersL_list, 20, True, True) # Fingers
        move_bone_layer(av.fingersR_list, 20, True, True) # Fingers
    #    move_bone_layer(av.face_list, 4, True) # Face Secondary

print(obj.name+": Moved bone layers.")


# Make all layers visible on the metarig.
if obj.type == 'ARMATURE':
    obj.show_in_front = True
    for i in range(32):
        obj.data.layers[i] = True

print(f"{obj.name}: All bone layers are now visible.")