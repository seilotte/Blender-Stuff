import bpy

av = bpy.context.scene.apex_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

for b in obj.data.bones:
    if b.layers[0] or b.layers[4] or b.layers[27] or b.name in [av.head1, av.chin, av.clavicle0_L, av.clavicle1_L, av.clavicle2_L, av.clavicle0_R, av.clavicle1_R, av.clavicle2_R]: # Hair, Face[Secondary] and Extreme Deform
        b = obj.pose.bones.get(b.name)
        if len(b.rigify_type) > 0:
            pass # Rig type alrady assinged.
        else:
            b.rigify_type = "basic.super_copy"
            b.rigify_parameters.super_copy_widget_type = "bone"
            
            if b.parent is None or (b.parent and b.parent.name == "root"):
                b.rigify_parameters.relink_constraints = False
            else:
                b.rigify_parameters.relink_constraints = True
                
                p = "DEF-" + b.parent.name
                b.rigify_parameters.parent_bone = p

print(f"{obj.name}: Assigned super copy rig type to leftovers.")