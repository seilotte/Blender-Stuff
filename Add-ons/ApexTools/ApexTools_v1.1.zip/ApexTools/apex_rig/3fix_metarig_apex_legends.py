import bpy
from mathutils import Matrix
from math import radians

av = bpy.context.scene.apex_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

def edit_bone_rotate(angle, axis):
    rotation_matrix = Matrix.Rotation(radians(angle), 4, axis)
    pivot_matrix = Matrix.Translation(b.head) # pivot point
    final_matrix = pivot_matrix @ rotation_matrix @ pivot_matrix.inverted() @ b.matrix
    b.matrix = final_matrix

# ===========================

listRotate = [ # -90 z_axis.
av.thumb_L[:-1]+"C",
av.index_L[:-1]+"C",
av.mid_L[:-1]+"C",
av.ring_L[:-1]+"C",
av.pinky_L[:-1]+"C",

av.leg3_L, # toe_L; We won't search for the last element of the leg list since we are hardcoding apex fixes. We know it's the third one.
av.arm2_L, # hand_L
"def_l_forearm", # Apex twist bones.
"def_l_shoulderMid",
]

listRotate2 = [ # 90 z_axis
av.thumb_R[:-1]+"C",
av.index_R[:-1]+"C",
av.mid_R[:-1]+"C",
av.ring_R[:-1]+"C",
av.pinky_R[:-1]+"C",

av.leg3_R, # toe_R
av.arm2_R, # hand_R
"def_r_forearm", # Apex twist bones.
"def_r_shoulderMid",
]


activeMode = obj.mode
bpy.ops.object.mode_set(mode="EDIT") # Edit bones only exist in edit mode.


for b in obj.data.edit_bones:
    if b is not None:
        b.length = b.length * 10 # Fix cast bones being to small.
        
        # Fix root
        if b.name == av.root:
            edit_bone_rotate(-90, b.x_axis)
            b.length = b.length * 50
            b.name = "root"
        
        # Fix parents.
        elif b.name == av.head0: #def_c_neckB; We won't search for last element of the spine list since we are hardcoding apex fixes
            b.parent = obj.data.edit_bones.get(av.spine4) #def_c_neckA
        elif b.name == av.arm1_L: # Mid; Elbow; All apex characters are humans...
            b.parent = obj.data.edit_bones.get(av.arm0_L) # Start; Shoulder.
        elif b.name == av.arm1_R:
            b.parent = obj.data.edit_bones.get(av.arm0_R)
        
        # Fix rotations.
        elif b.name in listRotate:
            edit_bone_rotate(-90, b.z_axis)
            if b.name == av.arm2_L or b.name == av.leg3_L: # Hand and toe.
                b.length = 0.05
        elif b.name in listRotate2:
            edit_bone_rotate(90, b.z_axis)
            if b.name == av.arm2_R or b.name == av.leg3_R: # Hand and toe.
                b.length = 0.05

# ===========================

# Add heel bones.
def apex_heel_bone(name, toBoneName, R=False):
    toBone = obj.data.bones.get(toBoneName)
    newBone = obj.data.edit_bones.new(name)
    if R:
        newBone.head = (-0.07, 0.1, 0)
        newBone.tail = (-0.17, 0.1, 0)
        newBone.layers[17] = True # Leg.R IK
        newBone.layers = [l == 17 for l in range(32)]
    else:
        newBone.head = (0.07, 0.1, 0)
        newBone.tail = (0.17, 0.1, 0)
        newBone.layers[14] = True # Leg.L IK
        newBone.layers = [l == 14 for l in range(32)]
    
    if toBone.parent:
        newBone.parent = obj.data.edit_bones[toBone.parent.name]

apex_heel_bone("Heel_L", av.leg3_L)
apex_heel_bone("Heel_R", av.leg3_R, True)


bpy.ops.object.mode_set(mode=activeMode)

print(f"{obj.name}: Fixed apex metarig.")