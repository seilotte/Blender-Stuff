import bpy
from mathutils import Matrix
from math import radians

av = bpy.context.scene.apex_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

def align_bones(bones_list, r=1, child_only=False): # r = remove_at_start
    # Fix apex_vars lists so it contains the custom strings.
    string_list = [getattr(av, i) for i in bones_list if hasattr(av, i) and getattr(av, i) != ""]
    
    # Align bones.
    if b.name in string_list[r:]:
        if not child_only:
            if b.parent is not None:
                b.parent.tail.xyz = b.head.xyz
                b.use_connect = True
        
        else:
            if b.children is not None:
                for c in b.children_recursive:
                    if len(c.name) == len(b.name): # Most likely fingers names will have the same length.
                        if c.parent is not None:
                            c.parent.tail.xyz = c.head.xyz
                            c.use_connect = True
    
    # Fixes for connected bones.
    if bones_list == av.spine_list:
        if b.name == string_list[1]:
            b.use_connect = True
        elif b.name == string_list[-1]:
            b.use_connect = False
    
    elif bones_list == av.armL_list or bones_list == av.armR_list:
        if b.name == string_list[0]:
            b.use_connect = False
    
    elif bones_list == av.head_list:
        if len(string_list) > 1: # Normally after the neck bone, there's the head bone.
            if b.name == string_list[1]:
                b.use_connect = False

# ===========================

activeMode = obj.mode
bpy.ops.object.mode_set(mode="EDIT") # Edit bones only exist in edit mode.


for b in obj.data.edit_bones:
    if b is not None:
        align_bones(av.spine_list, 2)
        align_bones(av.head_list, 0)
        align_bones(av.armL_list, 0)
        align_bones(av.armR_list, 0)
        align_bones(av.legL_list)
        align_bones(av.legR_list)
        align_bones(av.fingersL_list, 0, True)
        align_bones(av.fingersR_list, 0, True)
        align_bones(av.clavicleL_list)
        align_bones(av.clavicleR_list)


bpy.ops.object.mode_set(mode=activeMode)

print(f"{obj.name}: Aligned and connected bones.")