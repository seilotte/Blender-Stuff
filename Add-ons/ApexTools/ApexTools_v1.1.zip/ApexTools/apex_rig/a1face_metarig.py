import bpy

av = bpy.context.scene.apex_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

# =========================== Parent and align bones.

def duplicate_bone(toCopy):
    bone = obj.data.edit_bones.get(toCopy)
    # Rename bones.
    new_bone = obj.data.edit_bones.new(name=bone.name+"_L")
    bone.name = bone.name+"_R"
    # Copy parameters.
    new_bone.head = bone.head
    new_bone.tail = bone.tail
    new_bone.roll = bone.roll
    new_bone.layers = bone.layers

def string_list(lst):
    # Get custom strings form list with a list compression.
    string_list = [getattr(av, i) for i in lst if hasattr(av, i) and getattr(av, i) != ""]
    return string_list

def parent_bones(lst, save_parent=False):
    # 1 with 2, 2 with 3...
    for i in range(len(lst) - 1):
        previous_bone = o.get(lst[i])
        next_bone = o.get(lst[i + 1])
        
        # Save last bone parent.
        if o.get(lst[-1]) is not None:
            saved_parent = o.get(lst[-1]).parent
        
        # Parent bones.
        if previous_bone is not None and next_bone is not None:
            if previous_bone.parent == next_bone:
                previous_bone.parent = None
            next_bone.parent = previous_bone
        
        # Apply last bone (saved)parent to the first bone?
        if save_parent and o.get(lst[-1]) is not None:
            o.get(lst[0]).parent = saved_parent

def align_bones(bone_list_names):
    # Align bones.
    for name in bone_list_names:
        b = o.get(name)
#    if b.name in bone_list_names:
        if b.parent is not None and b is not None:
            b.parent.tail.xyz = b.head.xyz
            b.use_connect = True
    
    
    # Fixes for connected bones.
    # Corner lips are on the top lists.
    if bone_list_names == listTL or bone_list_names == listTR and b is not None:
        if b.name == bone_list_names[-1]:
            b.use_connect = False


activeMode = obj.mode
bpy.ops.object.mode_set(mode='EDIT') # Edit bones only exist in edit mode.

o = obj.data.edit_bones

# =========================== Eyebrows bones.

# Parent eyebrows bones.
listTL = string_list(av.eyebrowL_list)
listTR = string_list(av.eyebrowR_list)

parent_bones(listTL)
parent_bones(listTR)

# Align eyebrows bones.
align_bones(listTL[1:])
align_bones(listTR[1:])

# =========================== Eyes bones.

# Parent eyes bones.
listTL = string_list(av.eyeTL_list)
listBL = string_list(av.eyeBL_list)
listTR = string_list(av.eyeTR_list)
listBR = string_list(av.eyeBR_list)

listTL.insert(0, av.eye_L) # Add missing bones to list.
listBL.insert(0, av.eye_L)
listTR.insert(0, av.eye_R)
listBR.insert(0, av.eye_R)

parent_bones(listTL)
parent_bones(listBL)
parent_bones(listTR)
parent_bones(listBR)

# Align eyes bones.
align_bones(listTL[2:])
align_bones(listTR[2:])
align_bones(listBR[2:])
align_bones(listBL[2:])

# =========================== Lips bones.

# Create missing lips bones.
duplicate_bone(av.lip_C_T)
duplicate_bone(av.lip_C_B)

# Parent lips bones.
listTL = string_list(av.lipTL_list)
listBL = string_list(av.lipBL_list)
listTR = string_list(av.lipTR_list)
listBR = string_list(av.lipBR_list)

listTL.insert(0, av.lip_C_T+"_L") # Add missing bones to list.
listBL.insert(0, av.lip_C_B+"_L")
listTR.insert(0, av.lip_C_T+"_R")
listBR.insert(0, av.lip_C_B+"_R")

parent_bones(listTL)
parent_bones(listBL)
parent_bones(listTR)
parent_bones(listBR)


# Align new lips bones.
align_bones(listTL[1:])
align_bones(listTR[1:])
align_bones(listBR[1:])
align_bones(listBL[1:])

# Fix bottom lips bone, since corners not in lists.
o.get(listBL[-1]).tail = o.get(listTL[-1]).head
o.get(listBR[-1]).tail = o.get(listTR[-1]).head

del listTL
del listTR
del listBL
del listBR

# =========================== Tongue bones.

# Parent tongue bones.
list0 = string_list(av.tongue_list)

parent_bones(list0, save_parent=True) # If save_parent make sure to swap just like tongue.

# Align tongue bones.
b = o.get(list0[0])
if b.children is not None:
    for c in b.children_recursive:
        if c.parent is not None:
            c.tail = c.parent.head
        
# Swap tongue bones.
for name in list0:
    b = o.get(name)
    if b is not None:
        swap = b.head.xyz
        b.head.xyz = b.tail.xyz
        b.tail.xyz = swap
        
        if name != list0[0]:
            b.use_connect = True

del list0
del b

# =========================== Jaw bone.

# Parent to jaw bone.
o.get(av.chin).parent = o.get(av.jaw)
o.get(av.teeth_B).parent = o.get(av.jaw)
o.get(av.lip_C_T+"_L").parent = o.get(av.jaw) # We renamed the bones above.
o.get(av.lip_C_B+"_L").parent = o.get(av.jaw)
o.get(av.lip_C_T+"_R").parent = o.get(av.jaw)
o.get(av.lip_C_B+"_R").parent = o.get(av.jaw)

# Align jaw to chin.
o.get(av.jaw).tail = o.get(av.chin).head


bpy.ops.object.mode_set(mode=activeMode)

print(f"{obj.name}: Parented, aligned, and connected face bones.")



# =========================== Assign rig types, move layer and assign group.

def rig_type_settings(
                b, # b = pose_bone
                rig_type,
                orientation,
):
    
    for i in range(32): # Remove bone layers.
        b.rigify_parameters.fk_layers[i] = False
        b.rigify_parameters.tweak_layers[i] = False
        b.rigify_parameters.extra_ik_layers[i] = False
    b.rigify_type = rig_type
    
    if orientation:
        b.rigify_parameters.skin_control_orientation_bone = av.head0 # Almost always, head bone comes after the neck.
    
    # Super_copy.
    if rig_type == "basic.super_copy":
        b.rigify_parameters.super_copy_widget_type = "teeth"
    
    # Stretchy_chain
    elif rig_type == "skin.stretchy_chain":
        b.rigify_parameters.skin_chain_pivot_pos = 2
        
        b.rigify_parameters.skin_chain_falloff_twist = True
        b.rigify_parameters.skin_chain_falloff_scale = True
        
        b.rigify_parameters.skin_primary_layers_extra = True
        b.rigify_parameters.skin_secondary_layers_extra = True
        for i in range(32):
            b.rigify_parameters.skin_primary_layers[i] = False
            b.rigify_parameters.skin_secondary_layers[i] = False
        b.rigify_parameters.skin_primary_layers[3] = True # Face Primary
        b.rigify_parameters.skin_secondary_layers[4] = True # Face Secondary
        
        e = b.rigify_parameters.skin_chain_use_scale
        e[0] = True
        e[1] = True
        e[2] = True
        e[3] = True


def move_bone_layer(bone_names, tolayer, rig_type_map=False, lst=True):
    if lst: # Access strings of the list with a list compression.
        bone_names = [getattr(av, i) for i in bone_names if hasattr(av, i) and getattr(av, i) != ""]
    
    # Move bone layers.
#    for b in obj.data.bones:
#        if b is not None:
    if b.name in bone_names:
        b.layers = [layer == tolayer for layer in range(32)] # Disable rest of layers with a list compression.
        if b.name == bone_names[0] and rig_type_map or lst == False and rig_type_map:
            pose_bone = obj.pose.bones.get(b.name)
            rig_type_settings(pose_bone, *rigify_map.get(rig_type_map))
            
            # Assign the bone group.
            # TODO: Add the group_name input to the function.
            # We already checked if it exists in 2assign_rig_types.py
            pose_bone.bone_group = obj.pose.bone_groups.get("Rig_Types")


rigify_map = { # Used in assign_rigtype().
#av.arm0_L: ("limbs.super_limb", True, "arm", True, 9, True, 7, False, False, False, 0),
"chain": ("skin.stretchy_chain", False),
"chain_orient": ("skin.stretchy_chain", True),
"eye": ("face.skin_eye", False),
"jaw": ("face.skin_jaw", False),
"tongue": ("face.basic_tongue", False),
"teeth": ("basic.super_copy", False),
}


for b in obj.data.bones:
    if b is not None:
        move_bone_layer(av.eyebrowL_list, 2, "chain") # 2 = Face layer.
        move_bone_layer(av.eyebrowR_list, 2, "chain")
        
        move_bone_layer(av.eye_L, 2, "eye", False) # list = False
        move_bone_layer(av.eyeTL_list, 2, "chain_orient")
        move_bone_layer(av.eyeBL_list, 2, "chain_orient")
        move_bone_layer(av.eye_R, 2, "eye", False)
        move_bone_layer(av.eyeTR_list, 2, "chain_orient")
        move_bone_layer(av.eyeBR_list, 2, "chain_orient")
        
        move_bone_layer(av.jaw, 2, "jaw", False)
        move_bone_layer(av.chin, 2, lst=False)
        move_bone_layer(av.teeth_T, 2, "teeth", False)
        move_bone_layer(av.teeth_B, 2, "teeth", False)
        
        move_bone_layer(av.lip_C_T+"_L", 2, "chain_orient", False)
        move_bone_layer(av.lip_C_B+"_L", 2, "chain_orient", False)
        move_bone_layer(av.lip_C_T+"_R", 2, "chain_orient", False)
        move_bone_layer(av.lip_C_B+"_R", 2, "chain_orient", False)
        move_bone_layer(av.lipTL_list, 2)
        move_bone_layer(av.lipBL_list, 2)
        move_bone_layer(av.lipTR_list, 2)
        move_bone_layer(av.lipBR_list, 2)
        
        move_bone_layer(av.tongue_list, 2, "tongue")

print(f"{obj.name}: Moved face bone layers and assigned face rig types.")



# =========================== Rename bones.

def rename_bones(lst, toname, add_name=False, remove_names=False):
    # Get custom strings form list with a list compression.
    string_list = [getattr(av, i) for i in lst if hasattr(av, i) and getattr(av, i) != ""]
    if remove_names:
        string_list[:remove_names]
    if add_name:
        string_list.insert(0, add_name)
    
    for i in range(len(string_list)):
        obj.data.bones.get(string_list[i]).name = toname

rename_bones(av.eyebrowL_list, "brow.T_L")
rename_bones(av.eyebrowR_list, "brow.T_R")

rename_bones(av.eyeTL_list, "lid.T_L")
rename_bones(av.eyeBL_list, "lid.B_L")
rename_bones(av.eyeTR_list, "lid.T_R")
rename_bones(av.eyeBR_list, "lid.B_R")

rename_bones(av.lipTL_list, "lip.T_L", av.lip_C_T+"_L", -1)
rename_bones(av.lipBL_list, "lip.B_L", av.lip_C_B+"_L", -1)
rename_bones(av.lipTR_list, "lip.T_R", av.lip_C_T+"_R", -1)
rename_bones(av.lipBR_list, "lip.B_R", av.lip_C_B+"_R", -1)


print(f"{obj.name}: Renamed face bones.")