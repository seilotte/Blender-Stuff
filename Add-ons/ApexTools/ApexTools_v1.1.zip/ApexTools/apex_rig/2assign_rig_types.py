import bpy

av = bpy.context.scene.apex_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

def rig_type_settings(
                b, # Bone
                rig_type,
                ik_wrist,
                lmb_type,
                fk_lyrs,
                fk_layer,
                twk_lyrs,
                tweak_layer,
                cnt_chain,
                ik_finger,
                ik_lyrs_extra,
                ik_layer_extra,
):
    
    for i in range(32): # Remove bone layers.
        b.rigify_parameters.fk_layers[i] = False
        b.rigify_parameters.tweak_layers[i] = False
        b.rigify_parameters.extra_ik_layers[i] = False
    b.rigify_type = rig_type
    b.rigify_parameters.make_ik_wrist_pivot = ik_wrist
    b.rigify_parameters.limb_type = lmb_type
    if fk_lyrs:
        b.rigify_parameters.fk_layers[fk_layer] = True
    if twk_lyrs:
        b.rigify_parameters.tweak_layers[tweak_layer] = True
    b.rigify_parameters.connect_chain = cnt_chain
    b.rigify_parameters.make_extra_ik_control = ik_finger
    if ik_lyrs_extra:
        b.rigify_parameters.extra_ik_layers_extra = True
        b.rigify_parameters.extra_ik_layers[ik_layer_extra] = True


def assign_rigtype(lyr, bone_strings, lst=False, group_name="Rig_Types"):
    if lst:
        bone_strings = [getattr(av, i) for i in bone_strings if hasattr(av, i) and getattr(av, i) != ""]
    
    # Check for layer and name.
#    for bone in obj.data.bones:
    if bone.layers[lyr] and bone.name in bone_strings:
        b = obj.pose.bones.get(bone.name)
        if not lst:
            rig_type_settings(b, *rigify_map.get(b.name))
        else:
            rig_type_settings(b, *rigify_map.get("finger_rigtype")) # Since we only have fingers as a list...
        
        # Assign the bone group.
        if group_name in obj.pose.bone_groups:
            group = obj.pose.bone_groups.get(group_name)
        else:
            group = obj.pose.bone_groups.new(name=group_name)
            group.color_set = 'CUSTOM'
            group.colors.normal = (0.97, 0.26, 0.57)
            group.colors.select = (0.6, 0.9, 1.0)
            group.colors.active = (0.769, 1.0, 1.0)
        b.bone_group = group

# ===========================

# Get the last spine string in the list.
e = -1 # Last element with a string.
for i in av.spine_list:
    if hasattr(av, i) and getattr(av, i) != "":
        e += 1

if e > 0: 
    spine_x = f"spine{e}"
    if hasattr(av, spine_x) and getattr(av, spine_x) != "":
        spine_last_string = getattr(av, spine_x)
else:
    spine_last_string = ""


rigify_map = { # Used in assign_rigtype().
av.arm0_L: ("limbs.super_limb", True, "arm", True, 9, True, 7, False, False, False, 0),
av.arm0_R: ("limbs.super_limb", True, "arm", True, 12, True, 7, False, False, False, 0),
av.leg0_L: ("limbs.super_limb", False, "leg", True, 15, True, 7, False, False, False, 0),
av.leg0_R: ("limbs.super_limb", False, "leg", True, 18, True, 7, False, False, False, 0),
av.spine0: ("spines.basic_spine", False, "arm", True, 6, True, 7, False, False, False, 0),
spine_last_string: ("spines.super_head", False, "arm", False, 0, True, 7, True, False, False, 0),
"finger_rigtype": ("limbs.super_finger", False, "arm", False, 0, True, 22, False, True, True, 21),
}

for bone in obj.data.bones:
    if bone is not None:
        assign_rigtype(5, av.spine0) # Torso[IK]
        assign_rigtype(5, spine_last_string)
        assign_rigtype(8, av.arm0_L) # Arm.L IK
        assign_rigtype(11, av.arm0_R) # Arm.R IK
        assign_rigtype(14, av.leg0_L) # Leg.L IK
        assign_rigtype(17, av.leg0_R) # Leg.R IK
        assign_rigtype(20, av.fingersL_list, True) # Fingers
        assign_rigtype(20, av.fingersR_list, True)

print(f"{obj.name}: Assigned rig types.")