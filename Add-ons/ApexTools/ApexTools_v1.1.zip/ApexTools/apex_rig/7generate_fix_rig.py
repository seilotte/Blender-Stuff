import bpy

av = bpy.context.scene.apex_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.
metarig_name = obj.name

x = 0 # Metarig has rig type?
if obj.type == 'ARMATURE':
    for b in obj.data.bones:
        if len(obj.pose.bones.get(b.name).rigify_type) > 0:
            x += 1
            break

# ===========================

def move_bone_layer(lyr):
    b.layers = [layer == lyr for layer in range(32)]

def assign_bone_group(bone_name, group):
#    o.pose.bones[bone_name].bone_group = o.pose.bone_groups[group]
    o.pose.bones.get(bone_name).bone_group = o.pose.bone_groups.get(group)

def twist_bone(bone_name, hand_tweak,  lowarm_tweak, infl):
    b = o.pose.bones.get(bone_name)
    if b:
        constraint = b.constraints.new("COPY_ROTATION")
        constraint.target = o # o = rigify armature
        constraint.subtarget = hand_tweak
        constraint.use_x = False
        constraint.use_y = True
        constraint.use_z = False
        constraint.target_space = "CUSTOM"
        constraint.owner_space = "LOCAL"
        constraint.space_object = o
        constraint.space_subtarget = lowarm_tweak
        constraint.influence = infl

if x > 0:
    del x
    bpy.ops.pose.rigify_generate()
    
    o = bpy.context.view_layer.objects.get("RIG-"+metarig_name) # o = rigify rig
    activeMode = o.mode
    
    if o.type == 'ARMATURE':
        av.from_armature = o
        obj.hide_viewport = True
        obj.hide_render = True
        
        o.show_in_front = True
        
        # Make certain layers active.
        for c in range(32):
            o.data.layers[c] = False
        for i in [2, 5, 8, 11, 14, 17, 20, 22, 28]:
            o.data.layers[i] = True
        
# =========================== Start lists.
        
        # Clavicles lists.
        # Get custom strings from the list with a list compression.
        clavicleL_string_list = [getattr(av, i) for i in av.clavicleL_list if hasattr(av, i) and getattr(av, i) != ""]
        clavicleR_string_list = [getattr(av, i) for i in av.clavicleR_list if hasattr(av, i) and getattr(av, i) != ""]
        
        # Extra, from arms and legs lists.
        # Get custom strings from the list with a list compression.
        armL_string_list = [getattr(av, i) for i in av.armL_list if hasattr(av, i) and getattr(av, i) != ""]
        armR_string_list = [getattr(av, i) for i in av.armR_list if hasattr(av, i) and getattr(av, i) != ""]
        legL_string_list = [getattr(av, i) for i in av.legL_list if hasattr(av, i) and getattr(av, i) != ""]
        legR_string_list = [getattr(av, i) for i in av.legR_list if hasattr(av, i) and getattr(av, i) != ""]
        
        arms_legs_list = [] # Arms and legs bones with rig types.
        arms_legs_list.append(armL_string_list[0])
        arms_legs_list.append(armR_string_list[0])
        arms_legs_list.append(legL_string_list[0])
        arms_legs_list.append(legR_string_list[0])
        del armL_string_list
        del armR_string_list
        del legL_string_list
        del legR_string_list
        
        arms_legs_list_ik = ["def_l_ankle_spin_ik", "def_r_ankle_spin_ik"] # Apex ankle bones.
        for i in arms_legs_list:
            arms_legs_list_ik.append(i+"_ik")
        
        arms_legs_list_parent = []
        for i in arms_legs_list:
            arms_legs_list_parent.append(i+"_parent")
        del arms_legs_list
        
        arms_legs_list_pole = []
        for i in arms_legs_list_ik:
            arms_legs_list_pole.append("VIS_"+i+"_pole")
        
# =========================== End lists.
        
        for b in o.data.bones:
            # Move bone layers.
            # Clavicles.
            if b.name in clavicleL_string_list or b.name in clavicleR_string_list:
                move_bone_layer(5) # Torso[IK]
            
            # Extra, from arms and legs.
            elif b.name in arms_legs_list_ik:
                move_bone_layer(26) # Extra
            
            elif b.name in arms_legs_list_parent:
                move_bone_layer(26)
                o.pose.bones.get(b.name)["pole_vector"] = 1
                o.pose.bones.get(b.name)["IK_Stretch"] = 0
            
            elif b.name == av.chin: # TODO: When jaw bone_chain, remove this.
                move_bone_layer(3)
            
            
            # Assign bone groups.
            elif b.name in arms_legs_list_pole:
                assign_bone_group(b.name, "Root")
            
            # Fix bone head size and position.
            elif av.head0:
                if b.name == "head":
                    o.pose.bones.get(b.name).custom_shape_scale_xyz[0] = 2.0
                    o.pose.bones.get(b.name).custom_shape_scale_xyz[1] = 1.6 # Translates on y.
                    o.pose.bones.get(b.name).custom_shape_scale_xyz[2] = 2.0
#                    o.pose.bones.get(b.name).custom_shape_translation[1] = 0.05
            
            
            # Twist bones constraints.
            if b.name == "def_l_forearm":
                twist_bone(b.name, f"{av.arm2_L}_tweak", f"{av.arm1_L}_tweak.001", 0.5)
            
            elif b.name == "def_r_forearm":
                twist_bone(b.name, f"{av.arm2_R}_tweak", f"{av.arm1_R}_tweak.001", 0.5)
            
            elif b.name == "def_l_shoulderMid":
                twist_bone(b.name, f"{av.arm2_L}_tweak", f"{av.arm0_L}_tweak.001", 0.1)
            
            elif b.name == "def_r_shoulderMid":
                twist_bone(b.name, f"{av.arm2_R}_tweak", f"{av.arm0_R}_tweak.001", 0.1)


print(f"{o.name}: Fixed rigify body rig.")