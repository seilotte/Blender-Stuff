import bpy

av = bpy.context.scene.apex_variables
# Obj is rigify rig since we generated it in previous script.
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.
metarig_name = obj.name

x = 0 # Metarig has rig type?
if obj.type == 'ARMATURE':
    for b in obj.data.bones:
        if len(obj.pose.bones.get(b.name).rigify_type) > 0:
            x += 1
            break

# ===========================

def move_bone_layer(bone, lyr):
    b = obj.data.bones.get(bone)
    if b is not None:
        b.layers = [layer == lyr for layer in range(32)]

def assign_bone_group(group):
    b.bone_group = obj.pose.bone_groups.get(group)

# Get the strings of the custom_variables list.
def string_list(lst):
    string_list = [getattr(av, i) for i in lst if hasattr(av, i) and getattr(av, i) != ""]
    return string_list

# Move chain bones.
def move_bone_chain(bone_name, lst, lyr=3, lyr_condition=2):
    # Get the strings of the custom_variables list.
    string_list = [getattr(av, i) for i in lst if hasattr(av, i) and getattr(av, i) != ""]
    
    # It should be the length of the bone children.
    # Start from the [1] item, and make steps of 2 in list.
    for i in range(1, len(string_list), 2):
#        if i < 9: # Custom_lists doesn't go higher than 9.

        # Only move bones in this layer.
        if lyr_condition:
            b = obj.data.bones.get(f"{bone_name}.00{i}")
            if b is not None and b.layers[lyr_condition]:
                b.layers = [layer == lyr for layer in range(32)]


if x > 0:
    del x
    
    if obj.type == 'ARMATURE':
        
        o = obj.pose.bones # o in this script is not edit_bones or data.bones.
        
        # Assign group to jaw.
        o.get(av.jaw).bone_group = obj.pose.bone_groups.get("FK")
        
        
        # Fix tongue.
        list0 = string_list(av.tongue_list)
        
        # Fix tongue bone size.
        o.get(list0[0]).custom_shape_scale_xyz[2] = 2.0
#        o.get(list0[0]).bone_group = obj.pose.bone_groups.get("FK")
        
        # Fix tongue groups and layer.
        for i in list0:
            i = "tweak_"+i
            b = o.get(i)
            move_bone_layer(b.name, 4) # Face[Secondary]
            assign_bone_group("Tweak")
        
        # Tongue rig type generates last_bone.001.
        b = o.get(f"tweak_{list0[-1]}.001")
        move_bone_layer(b.name, 4)
        assign_bone_group("Tweak")
        del list0
        
        
        # Fix eyebrows, eyes and lips. Remember they get renamed.
        # Fix layers and move to face secondary.
        move_bone_chain("brow.T_L", av.eyebrowL_list, 3) # 3 = Face[Primary]
        move_bone_chain("brow.T_R", av.eyebrowR_list, 3, 2) # 2 =Only in face layer.
        
        move_bone_chain("lid.T_L", av.eyeTL_list)
        move_bone_chain("lid.B_L", av.eyeBL_list)
        move_bone_chain("lid.T_R", av.eyeTR_list)
        move_bone_chain("lid.B_R", av.eyeBR_list)
        
        move_bone_chain("lip.T_L", av.lipTL_list)
        move_bone_chain("lip.B_L", av.lipBL_list)
        move_bone_chain("lip.T_R", av.lipTR_list)
        move_bone_chain("lip.B_R", av.lipBR_list)
        
        # Fix lips corner.
        list0 = string_list(av.lipTL_list) # Corners and on the top list.
        move_bone_layer(f"lip.T_L.00{len(list0)}", 3)
        obj.data.bones.get(f"lip.T_L.00{len(list0)}").name = list0[-1]
        
        list0 = string_list(av.lipTR_list)
        move_bone_layer(f"lip.T_R.00{len(list0)}", 3)
        obj.data.bones.get(f"lip.T_R.00{len(list0)}").name = list0[-1]
        del list0


print(f"{obj.name}: Fixed rigify face rig.")