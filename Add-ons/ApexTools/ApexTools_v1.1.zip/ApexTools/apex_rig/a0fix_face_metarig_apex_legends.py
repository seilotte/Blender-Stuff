import bpy
from mathutils import Matrix
from math import radians

av = bpy.context.scene.apex_variables
obj = bpy.context.view_layer.objects.active # ARMATURE check in metarig operator.

def edit_bone_rotate(angle, axis):
    rotation_matrix = Matrix.Rotation(radians(angle), 4, axis)
    pivot_matrix = Matrix.Translation(b.head) # pivot point
    final_matrix = pivot_matrix @ rotation_matrix @ pivot_matrix.inverted() @ b.matrix
    b.matrix = final_matrix

# Renames custom_variables.
def search_bones(bone_name, condition, condition2=False):
    if not obj.data.bones.get(bone_name):
        for b in obj.data.bones:
            if condition in b.name:
                bone_name = b.name
                break
            if condition2:
                if condition2 in b.name:
                    bone_name = b.name
                    break
    return bone_name

# Get the strings of the custom_variables list.
def string_list(lst):
    string_list = [getattr(av, i) for i in lst if hasattr(av, i) and getattr(av, i) != ""]
    return string_list

# ===========================

# Fix/Find names.
av.jaw = search_bones(av.jaw, "jaw") # Apex "jaw" is always in lowercase.
av.teeth_T = search_bones(av.teeth_T, "upperJaw", "teethTop") # Apex teeth might be names "Jaw", with uppercase.
av.teeth_B = search_bones(av.teeth_B, "lowerJaw", "teethBot")


activeMode = obj.mode
bpy.ops.object.mode_set(mode="EDIT") # Edit bones only exist in edit mode.

o = obj.data.edit_bones

# Align jaw with chin.
o.get(av.jaw).head[0] = o.get(av.chin).head[0]
o.get(av.jaw).roll = 0.0


# Fix rotations and length.

# Left and right eye.
b = o.get(av.eye_L)
edit_bone_rotate(90, b.x_axis)

b = o.get(av.eye_R)
edit_bone_rotate(90, b.x_axis)


# Outside left eye.
listT = string_list(av.eyeTL_list)
b = o.get(listT[-1]) # b = bone
b.length = b.length * 0.5
edit_bone_rotate(120, b.z_axis)

listB = string_list(av.eyeBL_list)
b = o.get(listB[-1])
b.length = b.length * 0.3
edit_bone_rotate(-60, b.z_axis)
edit_bone_rotate(-45, b.x_axis)

# Move heads to tails.
o.get(listT[0]).head = o.get(listB[-1]).tail
o.get(listB[0]).head = o.get(listT[-1]).tail


# Outside right eye.
listT = string_list(av.eyeTR_list)
b = o.get(listT[-1]) # b = bone
b.length = b.length * 0.5
edit_bone_rotate(-120, b.z_axis)

listB = string_list(av.eyeBR_list)
b = o.get(listB[-1])
b.length = b.length * 0.3
edit_bone_rotate(60, b.z_axis)
edit_bone_rotate(-45, b.x_axis)

# Move heads to tails.
o.get(listT[0]).head = o.get(listB[-1]).tail
o.get(listB[0]).head = o.get(listT[-1]).tail

del listT
del listB


# Teeth upper.
b = obj.data.edit_bones.get(av.teeth_T)
b.length = b.length * 2.0
edit_bone_rotate(90, b.x_axis)

swap = b.head.xyz # Swap head with tail.
b.head.xyz = b.tail.xyz
b.tail.xyz = swap

# Teeth lower.
b = o.get(av.teeth_B)
b.length = b.length * 2.0
if b.head[0] < 0.001: # Fix for apex legends lower teeths.
    edit_bone_rotate(90, b.x_axis)
else:
    edit_bone_rotate(180, b.x_axis)

swap = b.head.xyz # Swap head with tail.
b.head.xyz = b.tail.xyz
b.tail.xyz = swap
del swap


# Eyebrows.
list0 = string_list(av.eyebrowL_list)
b = o.get(list0[-1])
edit_bone_rotate(110, b.z_axis)
edit_bone_rotate(5, b.x_axis)

list0 = string_list(av.eyebrowR_list)
b = o.get(list0[-1])
edit_bone_rotate(-110, b.z_axis)
edit_bone_rotate(5, b.x_axis)


# Tongue.
list0 = string_list(av.tongue_list)
b = o.get(list0[0])
edit_bone_rotate(90, b.x_axis)

del list0
del b

# =========================== Fix parents.

all_lips = []
all_lips.extend(av.lipTL_list)
all_lips.extend(av.lipBL_list)
all_lips.extend(av.lipTR_list)
all_lips.extend(av.lipBR_list)

# Get custom strings from list.
all_lips = string_list(all_lips)
all_lips.append(av.lip_C_T)
all_lips.append(av.lip_C_B)

# Parent apex lips(n, sticky) to main lips(a).
x = False
for n in all_lips:
    n1 = n[:-2] + "_b" # n = name
    n2 = n[:-2] + "_sticky"
     
    for b in obj.data.edit_bones:
        if b.name == n1:
            b.parent = obj.data.edit_bones.get(n)
            b.length = b.length * 0.25
        elif b.name == n2:
            b.parent = obj.data.edit_bones.get(n)
            b.length = b.length * 0.25
del all_lips


# Parent to chin.
o.get("def_l_chinSide").parent = o.get(av.chin)
o.get("def_r_chinSide").parent = o.get(av.chin)
o.get("def_c_underChin").parent = o.get(av.chin)


bpy.ops.object.mode_set(mode=activeMode)

print(f"{obj.name}: Fixed apex face metarig.")