import bpy

class APEX_OT_AssignRig(bpy.types.Operator):
    bl_label = "Assign Rig"
    bl_idname = "apex.ot_assignrig"
    bl_description = "Assign the armature/rig to the selected meshes."
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(self, context):
        obj = context.scene.apex_variables.from_armature
        if not obj:
            return False
        return obj.type == 'ARMATURE'
    
    def execute(self, context):
        o = context.scene.apex_variables.from_armature # o = object
        x = 0 # Check ORG- to see if it's a rigify rig.
        if o.type == "ARMATURE":
            for b in o.data.bones:
                if b.layers[31]:
                    if b.name[:4] == "ORG-":
                        x += 1
                        break
        
            if x > 0:
                for c in context.selected_objects:
                    if c.type == 'MESH':
                        
                        # Add rig to armature modifier.
                        if "Armature" not in c.modifiers:
                            c.modifiers.new("Armature", 'ARMATURE')
                        c.modifiers["Armature"].object = o
                        
                        # Change vertex groups names.
                        for i in c.vertex_groups:
                            str = i.name
                            i.name = "DEF-"+str
            else:
                for c in context.selected_objects:
                    if c.type == 'MESH':
                        
                        # Add rig to armature modifier.
                        if "Armature" not in c.modifiers:
                            c.modifiers.new("Armature", 'ARMATURE')
                        c.modifiers["Armature"].object = o
                        
                        # Change vertex groups names.
                        for i in c.vertex_groups:
                            if i.name[:4] == "DEF-":
                                str = i.name
                                i.name = str[4:]
        
        return {'FINISHED'}

# ===========================

def register():
    bpy.utils.register_class(APEX_OT_AssignRig)

def unregister():
    bpy.utils.unregister_class(APEX_OT_AssignRig)