import bpy
from bpy.types import Panel

# Global panel UI properties.
class ApexPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Apex'

# Create omo test UI panel.
class APEX_PT_omo(ApexPanel, Panel):
    bl_label = 'omo'
    bl_idname = "APEX_PT_omo"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        pass

# ===========================

def register():
    bpy.utils.register_class(APEX_PT_omo)

def unregister():
    bpy.utils.unregister_class(APEX_PT_omo)