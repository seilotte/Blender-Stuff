import bpy
from bpy.props import EnumProperty, IntProperty, FloatProperty, PointerProperty, BoolProperty, StringProperty

# Create custom variables.
class Apex_Variables(bpy.types.PropertyGroup):

    # Nodes Data
    from_armature: PointerProperty(name="FromArmature", type=bpy.types.Object)
    dir: StringProperty(name="Folder Path", subtype='DIR_PATH', description="Path to the folder containing the images")
    aoNode: BoolProperty(name="AO Node?", description="Add blender ambient occlusion node. Increases render time")

    # Rigify Tools
# =========================== Metarig bones.

    # Root
    root: StringProperty(name="Root", default="jx_c_delta")
    
    # Spine bones.
    # TODO: Use blender CollectionProperty instead of lists and create them procedurally.
    spine_list = ["spine0", "spine1", "spine2", "spine3", "spine4", "spine5", "spine6"]

    spine0: StringProperty(name="Spine Start", default="def_c_hip") # Start
    spine1: StringProperty(name="Spine1", default="def_c_spineA") # Inbetweens
    spine2: StringProperty(name="Spine2", default="def_c_spineB")
    spine3: StringProperty(name="Spine3", default="def_c_spineC")
    spine4: StringProperty(name="Spine4", default="def_c_neckA")
    spine5: StringProperty(name="Spine5")
    spine6: StringProperty(name="Spine6")
    
    # Head bones.
    head_list = ["head0", "head1", "head2"]
    
    head0: StringProperty(name="Head0", default="def_c_neckB") # Last spine element is the start.
    head1: StringProperty(name="Head1", default="def_c_head")
    head2: StringProperty(name="Head2")
    
    
    # Left clavicles bones.
    clavicleL_list = ["clavicle0_L", "clavicle1_L", "clavicle2_L"]
    
    clavicle0_L: StringProperty(name="Left Clavicle Start", default="def_l_clav") # Start
    clavicle1_L: StringProperty(name="Left Clavicle1")
    clavicle2_L: StringProperty(name="Left Clavicle2")
    
    # Right clavicles bones.
    clavicleR_list = ["clavicle0_R", "clavicle1_R", "clavicle2_R"]
    
    clavicle0_R: StringProperty(name="Right Clavicle Start", default="def_r_clav") # Start
    clavicle1_R: StringProperty(name="Right Clavicle1")
    clavicle2_R: StringProperty(name="Right Clavicle2")
    
    
    # Left arm bones.
    armL_list = ["arm0_L", "arm1_L", "arm2_L"]
    
    arm0_L: StringProperty(name="Left Arm Start", default="def_l_shoulder") # Start
    arm1_L: StringProperty(name="Left Arm Mid", default="def_l_elbow") # Inbetween
    arm2_L: StringProperty(name="Left Arm End", default="def_l_wrist") # End
    
    # Right arm bones.
    armR_list = ["arm0_R", "arm1_R", "arm2_R"]
    
    arm0_R: StringProperty(name="Right Arm Start", default="def_r_shoulder") # Start
    arm1_R: StringProperty(name="Right Arm Mid", default="def_r_elbow") # Inbetween
    arm2_R: StringProperty(name="Right Arm End", default="def_r_wrist") # End
    
    
    # Left leg bones.
    legL_list = ["leg0_L", "leg1_L", "leg2_L", "leg3_L", "leg4_L", "leg5_L"]
    
    leg0_L: StringProperty(name="Left Leg Start", default="def_l_thigh") # Start
    leg1_L: StringProperty(name="Left Leg1", default="def_l_knee") # Inbetween
    leg2_L: StringProperty(name="Left Leg2", default="def_l_ankle")
    leg3_L: StringProperty(name="Left Leg3", default="def_l_ball")
    leg4_L: StringProperty(name="Left Leg4")
    leg5_L: StringProperty(name="Left Leg5") # Why you have four and five?
    
    # Right leg bones.
    legR_list = ["leg0_R", "leg1_R", "leg2_R", "leg3_R", "leg4_R", "leg5_R"]
    
    leg0_R: StringProperty(name="Right Leg Start", default="def_r_thigh") # Start
    leg1_R: StringProperty(name="Right Leg1", default="def_r_knee") # Inbetween
    leg2_R: StringProperty(name="Right Leg2", default="def_r_ankle")
    leg3_R: StringProperty(name="Right Leg3", default="def_r_ball")
    leg4_R: StringProperty(name="Right Leg4")
    leg5_R: StringProperty(name="Right Leg5")
    
    
    # Left fingers bones.
    fingersL_list = ["thumb_L", "index_L", "mid_L", "ring_L", "pinky_L"]
    
    thumb_L: StringProperty(name="Left Thumb", default="def_l_finThumbA")
    index_L: StringProperty(name="Left Index", default="def_l_finIndexA")
    mid_L: StringProperty(name="Left Middle", default="def_l_finMidA")
    ring_L: StringProperty(name="Left Ring", default="def_l_finRingA")
    pinky_L: StringProperty(name="Left Pinky", default="def_l_finPinkyA")
    
    # Right fingers bones.
    fingersR_list = ["thumb_R", "index_R", "mid_R", "ring_R", "pinky_R"]
    
    thumb_R: StringProperty(name="Right Thumb", default="def_r_finThumbA")
    index_R: StringProperty(name="Right Index", default="def_r_finIndexA")
    mid_R: StringProperty(name="Right Middle", default="def_r_finMidA")
    ring_R: StringProperty(name="Right Ring", default="def_r_finRingA")
    pinky_R: StringProperty(name="Right Pinky", default="def_r_finPinkyA")

# =========================== Brows and eyes bones.

    # Left eyebrows.
    eyebrowL_list = ["eyebrow0_L", "eyebrow1_L", "eyebrow2_L", "eyebrow3_L", "eyebrow4_L", "eyebrow5_L"]
    
    eyebrow0_L: StringProperty(name="Left Eyebrow Start", default="def_l_foreheadOut")
    eyebrow1_L: StringProperty(name="Left Eyebrow 1", default="def_l_foreheadMid")
    eyebrow2_L: StringProperty(name="Left Eyebrow 2", default="def_l_foreheadIn")
    eyebrow3_L: StringProperty(name="Left Eyebrow 3")
    eyebrow4_L: StringProperty(name="Left Eyebrow 4")
    eyebrow5_L: StringProperty(name="Left Eyebrow 5")
    
    # Right eyebrows.
    eyebrowR_list = ["eyebrow0_R", "eyebrow1_R", "eyebrow2_R", "eyebrow3_R", "eyebrow4_R", "eyebrow5_R"]
    
    eyebrow0_R: StringProperty(name="Right Eyebrow Start", default="def_r_foreheadOut")
    eyebrow1_R: StringProperty(name="Right Eyebrow 1", default="def_r_foreheadMid")
    eyebrow2_R: StringProperty(name="Right Eyebrow 2", default="def_r_foreheadIn")
    eyebrow3_R: StringProperty(name="Right Eyebrow 3")
    eyebrow4_R: StringProperty(name="Right Eyebrow 4")
    eyebrow5_R: StringProperty(name="Right Eyebrow 5")
    
    
    # Left eye bones.
    eye_L: StringProperty(name="Left Eye", default="def_l_eyeball")
    eyeTL_list = ["eye0_T_L", "eye1_T_L", "eye2_T_L", "eye3_T_L", "eye4_T_L"]
    
    eye0_T_L: StringProperty(name="Left Upper Eye Start", default="def_l_eyelidUpperOutter")
    eye1_T_L: StringProperty(name="Left Upper Eye 1", default="def_l_eyelidUpper")
    eye2_T_L: StringProperty(name="Left Upper Eye 2", default="def_l_eyelidUpperInner")
    eye3_T_L: StringProperty(name="Left Upper Eye 3")
    eye4_T_L: StringProperty(name="Left Upper Eye 4")
    
    eyeBL_list = ["eye0_B_L", "eye1_B_L", "eye2_B_L", "eye3_B_L", "eye4_B_L"]
    
    eye0_B_L: StringProperty(name="Left Bottom Eye Start", default="def_l_eyelidLowerInner")
    eye1_B_L: StringProperty(name="Left Bottom Eye 1", default="def_l_eyelidLower")
    eye2_B_L: StringProperty(name="Left Bottom Eye 2", default="def_l_eyelidLowerOutter")
    eye3_B_L: StringProperty(name="Left Bottom Eye 3")
    eye4_B_L: StringProperty(name="Left Bottom Eye 4")
    
    # Right eye bones.
    eye_R: StringProperty(name="Right Eye", default="def_r_eyeball")
    eyeTR_list = ["eye0_T_R", "eye1_T_R", "eye2_T_R", "eye3_T_R", "eye4_T_R"]
    
    eye0_T_R: StringProperty(name="Right Upper Eye Start", default="def_r_eyelidUpperOutter")
    eye1_T_R: StringProperty(name="Right Upper Eye 1", default="def_r_eyelidUpper")
    eye2_T_R: StringProperty(name="Right Upper Eye 2", default="def_r_eyelidUpperInner")
    eye3_T_R: StringProperty(name="Right Upper Eye 3")
    eye4_T_R: StringProperty(name="Right Upper Eye 4")
    
    eyeBR_list = ["eye0_B_R", "eye1_B_R", "eye2_B_R", "eye3_B_R", "eye4_B_R"]
    
    eye0_B_R: StringProperty(name="Right Bottom Eye Start", default="def_r_eyelidLowerInner")
    eye1_B_R: StringProperty(name="Right Bottom Eye 1", default="def_r_eyelidLower")
    eye2_B_R: StringProperty(name="Right Bottom Eye 2", default="def_r_eyelidLowerOutter")
    eye3_B_R: StringProperty(name="Right Bottom Eye 3")
    eye4_B_R: StringProperty(name="Right Bottom Eye 4")
    
# =========================== Mouth bones.
    
    # Jaw and chin bone.
    jaw: StringProperty(name="Jaw", default="def_c_jawA")
    chin: StringProperty(name="Chin", default="def_c_chin")
    teeth_T: StringProperty(name="Upper Teeth", default="def_c_teethTop")
    teeth_B: StringProperty(name="Bottom Teeth", default="def_c_teethBot_manual")
    
    
    # Lip bones.
    # Center lip bones.
    lip_C_T: StringProperty(name="Center Top Lip", default="def_c_lipUpper_a") # C = Center
    lip_C_B: StringProperty(name="Center Bottom Lip", default="def_c_lipLower_a")
    
#    lip_list = ["lip0_T_L", "lip1_T_L", "lip2_T_L", "lip3_T_L", "lip0_B_L", "lip1_B_L", "lip2_B_L", "lip3_B_L", "lip0_T_R", "lip1_T_R", "lip2_T_R", "lip3_T_R", "lip0_B_R", "lip1_B_R", "lip2_B_R", "lip3_B_R"]
    lipTL_list = ["lip0_T_L", "lip1_T_L", "lip2_T_L", "lip3_T_L", "lip4_T_L"]
    
    lip0_T_L: StringProperty(name="Left Upper Lip Start", default="def_l_innerlipUpper_a")
    lip1_T_L: StringProperty(name="Left Upper Lip 1", default="def_l_lipUpperCenter_a")
    lip2_T_L: StringProperty(name="Left Upper Lip 2", default="def_l_lipUpperOuter_a")
    lip3_T_L: StringProperty(name="Left Upper Lip 3", default="def_l_lipCorner_a")
    lip4_T_L: StringProperty(name="Left Upper Lip 4") # Corner is the last bone on the top list.
    
    lipBL_list = ["lip0_B_L", "lip1_B_L", "lip2_B_L", "lip3_B_L"]
    
    lip0_B_L: StringProperty(name="Left Bottom Lip Start", default="def_l_lipLower_a")
    lip1_B_L: StringProperty(name="Left Bottom Lip 1", default="def_l_lipLowerOuter_a")
    lip2_B_L: StringProperty(name="Left Bottom Lip 2")
    lip3_B_L: StringProperty(name="Left Bottom Lip 3")
    
    lipTR_list = ["lip0_T_R", "lip1_T_R", "lip2_T_R", "lip3_T_R", "lip4_T_R"]
    
    lip0_T_R: StringProperty(name="Right Upper Lip Start", default="def_r_innerlipUpper_a")
    lip1_T_R: StringProperty(name="Right Upper Lip 1", default="def_r_lipUpperCenter_a")
    lip2_T_R: StringProperty(name="Right Upper Lip 2", default="def_r_lipUpperOuter_a")
    lip3_T_R: StringProperty(name="Right Upper Lip 3", default="def_r_lipCorner_a")
    lip4_T_R: StringProperty(name="Right Upper Lip 4") # Corner is the last bone on the top list.
    
    lipBR_list = ["lip0_B_R", "lip1_B_R", "lip2_B_R", "lip3_B_R"]
    
    lip0_B_R: StringProperty(name="Right Bottom Lip Start", default="def_r_lipLower_a")
    lip1_B_R: StringProperty(name="Right Bottom Lip 1", default="def_r_lipLowerOuter_a")
    lip2_B_R: StringProperty(name="Right Bottom Lip 2")
    lip3_B_R: StringProperty(name="Right Bottom Lip 3")
    
    
    # Tongue bones.
    tongue_list = ["tongue0", "tongue1", "tongue2", "tongue3", "tongue4"]
    
    tongue0: StringProperty(name="Tongue Start", default="def_c_tongue_d")
    tongue1: StringProperty(name="Tongue 1", default="def_c_tongue_c")
    tongue2: StringProperty(name="Tongue 2", default="def_c_tongue_b")
    tongue3: StringProperty(name="Tongue 3", default="def_c_tongue_a")
    tongue4: StringProperty(name="Tongue 4")

# ===========================

def register():
    bpy.utils.register_class(Apex_Variables)
    bpy.types.Scene.apex_variables = bpy.props.PointerProperty(type=Apex_Variables)

def unregister():
    bpy.utils.unregister_class(Apex_Variables)
    del bpy.types.Scene.apex_variables