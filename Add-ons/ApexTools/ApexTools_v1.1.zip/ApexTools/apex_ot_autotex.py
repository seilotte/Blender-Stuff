import bpy
import os
from bpy.types import Operator

loadImages = True
texSets = [
        ['albedoTexture'],
        ['scatterThicknessTexture'],
        ['specTexture'],
        ['glossTexture'],
        ['anisoSpecDirTexture'],
        ['emissiveTexture'],
        ['opacityMultiplyTexture'],
        ['cavityTexture'],
        ['normalTexture'],
        ['aoTexture'],
        ['iridescenceRampTexture'],
]

matSets = [
        "helmet",
        "hair",
        "head",
        "eye",
        "eyes",
        "eyecornea",
        "eyeshadow",
        "teeth",
        "body",
        "arms",
        "boots",
        "gauntlet",
        "jumpkit",
        "gear",
        "jacket",
        "suit"
]

# ===========================

# Auto texture, material nodes.
class APEX_OT_BatchApexMat(Operator):
    bl_label = "Auto-map Materials"
    bl_idname = "apex.ot_batch_mats"
    bl_description = "Batch process Apex materials"
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        apex_vars = context.scene.apex_variables
        
        # Append Apex Shader+ and fix for code not executing when appending (select).
        if bpy.data.node_groups.get('Apex Shader+') == None:
            selected = context.selected_objects
            bpy.ops.wm.append(directory = os.path.dirname(os.path.realpath(__file__)) + "\\Apex_Shader_Plus.blend\\NodeTree", filename ='Apex Shader+')
            for obj in selected:
                obj.select_set(True)
        
        for o in context.selected_objects:
            if o.type == 'MESH':
                for mSlot in o.material_slots:
                    MatNodeTree = bpy.data.materials[mSlot.name]
                    try:
                        imageNode = MatNodeTree.node_tree.nodes["Image Texture"]
                    except:
                        print(MatNodeTree.name+" 2x")
                        continue
                    
                    # Set directory.
                    if apex_vars.dir == "":
                        try: # ash_base_hair_albedoTexture.png
                            image = os.path.basename(bpy.path.abspath(imageNode.image.filepath))
                        except:
                            print(mSlot.name, "missing texture" + " or folder path is none.")
                            continue
                        
                        imagePath = os.path.dirname(bpy.path.abspath(imageNode.image.filepath))
                        listdir = os.listdir(imagePath)
                        
                        imageType = imageNode.image.name.split(".")[0].split('_')[-1] # albedoTexture
                        if not any (imageType in x for x in texSets):
                            print(image, "could not be mapped.")
                            continue
                    else:
                        imagePath = apex_vars.dir
                        listdir = os.listdir(imagePath)
                    

                    # List of names in directory.
                    imageType2 = mSlot.name.split('_')[-1] # hair
                    texImageNames = []
                    if imageType2 in matSets:
                        for listName in listdir:
                            if imageType2 in listName:
                                texImageNames.append(listName) # ash_base_hair_albedotexture.png
                    if texImageNames == []:
                        print(imageType2 + " missing texture.")
                        break
                    
                    # Image names variables.
                    for n in texImageNames:
                        n1 = n.split('_') # 'splits_all', 'hair', 'albedoTexture.png'
                        imageName = n.replace(n1[-1], '') # ash_base_hair_
                        imageFormat = n.split('.')[1] # png


                    # Material Creation.
                    MatN = MatNodeTree.node_tree
                    MatN.nodes.clear()
                    
                    # Image nodes logic.
                    for i in range(len(texSets)):
                        for j in range(len(texSets[i])):
                            texImageName = imageName + texSets[i][j] + '.' + imageFormat
                            texImage = bpy.data.images.get(texImageName)
                            texFile = imagePath + '\\' + texImageName
                            if not texImage and loadImages:
                                if os.path.isfile(texFile):
                                    texImage = bpy.data.images.load(texFile)

                            if texImage:
                                if i not in [0, 2, 10]: # albedo, specular, iridescenece; Order decided by texSets.
                                    texImage.colorspace_settings.name = 'Non-Color'
                                texImage.alpha_mode = 'CHANNEL_PACKED'
                                texNode = MatN.nodes.new('ShaderNodeTexImage')
                                texNode.image = texImage
                                texNode.name = str(i)
                                texNode.location = (-400, 250+i*-50)
                                texNode.hide = True
                                
                                break


                    # Apex Shader+ nodegroup.
                    NodeGroup = MatN.nodes.new('ShaderNodeGroup')
                    NodeGroup.node_tree = bpy.data.node_groups.get('Apex Shader+')
                    NodeGroup.location = (150,300)
                    NodeGroup.width = 250
                    # Material Output node.
                    NodeOutput = MatNodeTree.node_tree.nodes.new('ShaderNodeOutputMaterial')
                    NodeOutput.location = (500,300)
                    MatN.links.new(NodeOutput.inputs[0], NodeGroup.outputs[0])

                    # Links for Apex shader+.
                    ColorDict = {
                        "0": "Albedo",
                        "1": "Scatter Thickness (Radius)",
                        "2": "Specular",
                        "3": "Glossiness",
                        "4": "Anis-Spec Dir",
                        "5": "Emission",
                        "6": "Alpha (Opacity Multiply)",
                        "7": "Cavity",
                        "8": "Normal Map",
                        "9": "Ambient Occlusion",
                    }
                    AlphaDict = {
                        "1": "Scatter Thickness Alpha" # Number is texSets order.
                    }

                    for slot in AlphaDict:
                        try:
                            MatN.links.new(NodeGroup.inputs[AlphaDict[slot]], MatN.nodes[slot].outputs[1])
                        except:
                            pass
                    for slot in ColorDict:
                        try:
                            MatN.links.new(NodeGroup.inputs[ColorDict[slot]], MatN.nodes[slot].outputs[0])
                        except:
                            pass

# ===========================

                    # Blender Ambient Occlusion
                    if apex_vars.aoNode:
                        context.scene.eevee.use_gtao = True
                        NodeAO = MatN.nodes.new('ShaderNodeAmbientOcclusion')
                        NodeAO.location = (-300, -300)
                        MatN.links.new(NodeGroup.inputs[18], NodeAO.outputs[1])

                    mSlot.material.use_backface_culling = True
                    node_names = [n.name for n in MatN.nodes]

                    if "1" in node_names: # sss
                        MatN.links.new(NodeGroup.inputs[4], MatN.nodes["0"].outputs[0])
                        NodeGroup.inputs[1].default_value = 0.03

                    # Opacity multiply texture.
                    if {"5", "6", "10"}.issubset(node_names): # emission, opacity_multiply, iridescence
                        MatN.links.remove(MatN.nodes["6"].outputs[0].links[0])
                    elif {"5", "6"}.issubset(node_names): # emission * multiply
                        MatN.links.remove(MatN.nodes["6"].outputs[0].links[0])
                        MixRgb = MatNodeTree.node_tree.nodes.new('ShaderNodeMixRGB')
                        MixRgb.location = (-50, 0)
                        MixRgb.blend_type = 'MULTIPLY'
                        MixRgb.inputs[0].default_value = 1.0
                        MatN.links.new(NodeGroup.inputs[10], MixRgb.outputs[0])
                        MatN.links.new(MixRgb.inputs[1], MatN.nodes["5"].outputs[0])
                        MatN.links.new(MixRgb.inputs[2], MatN.nodes["6"].outputs[0])
                    elif "6" in node_names: # Make mat transparent.
                        mSlot.material.use_backface_culling = False
                        mSlot.material.blend_method = 'HASHED'
                        mSlot.material.shadow_method = 'HASHED'
                    
                    # Eye shadow.
                    if imageType2 == "eyeshadow" and {"0"}.issubset(node_names): # albedo
                        MatN.nodes.remove(NodeGroup)
                        NodeImageA = MatN.nodes["0"]
                        NodeImageA.hide = False
                        NodeOutputs = MatN.nodes["Material Output"]
                        # Mix Shader and transparent bsdf.
                        NodeMixS = MatN.nodes.new('ShaderNodeMixShader')
                        NodeMixS.location = (150, 300)
                        NodeTrans = MatN.nodes.new('ShaderNodeBsdfTransparent')
                        NodeTrans.location = (-50, 300)
                        MatN.links.new(NodeMixS.inputs[0], NodeImageA.outputs[1])
                        MatN.links.new(NodeMixS.inputs[1], NodeTrans.outputs[0])
                        MatN.links.new(NodeMixS.inputs[2], NodeImageA.outputs[0])
                        MatN.links.new(NodeOutput.inputs[0], NodeMixS.outputs[0])

                        mSlot.material.blend_method = 'BLEND'
                        mSlot.material.shadow_method = 'NONE'
                        
                    # Eyecornea nodes.
                    if imageType2 == "eyecornea" and {"8"}.issubset(node_names): # normal
                        MatN.nodes.remove(NodeGroup)
                        NodeOutput = MatN.nodes["Material Output"]
                        NodeImageNM = MatN.nodes["8"] # Normal map texture.
                        NodeImageNM.location  = (-600, -150)
                        NodeImageNM.hide = False
                        # Principled bsdf node.
                        NodePrinc = MatN.nodes.new('ShaderNodeBsdfPrincipled')
                        NodePrinc.location = (150,300)
                        NodePrinc.width = 250
                        NodePrinc.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
                        NodePrinc.inputs[9].default_value = 0.01 # Roughness
                        NodePrinc.inputs[16].default_value = 1.36 # IOR
                        NodePrinc.inputs[17].default_value = 1.0 # Transmission
                        MatN.links.new(NodeOutput.inputs[0], NodePrinc.outputs[0])
                        # Normal map and recalculate z nodes.
                        NodeZ = MatN.nodes.new('ShaderNodeGroup')
                        NodeZ.node_tree = bpy.data.node_groups.get('Recalculate "Z"')
                        NodeZ.location = (-300, -150)
                        MatN.links.new(NodeZ.inputs[0], NodeImageNM.outputs[0])
                        NodeNormalM = MatN.nodes.new('ShaderNodeNormalMap')
                        NodeNormalM.location = (-100, -150)
                        MatN.links.new(NodeNormalM.inputs[1], NodeZ.outputs[0])
                        MatN.links.new(NodePrinc.inputs[22], NodeNormalM.outputs[0])
                        
                        mSlot.material.use_backface_culling = False
                        mSlot.material.blend_method = 'HASHED'
                        mSlot.material.shadow_method = 'HASHED'
                        mSlot.material.use_screen_refraction = True
                        context.scene.eevee.use_ssr = True
                        context.scene.eevee.use_ssr_refraction = True

        return {'FINISHED'}

# ===========================

#Register
def register():
    bpy.utils.register_class(APEX_OT_BatchApexMat)
    
def unregister():
    bpy.utils.unregister_class(APEX_OT_BatchApexMat)