import bpy
import os

# Initiate rigify.
# Move bone layers.
# Assing rig types.
# Assign super_copy.
# Fix rig based on the game rig. (rotation, lengths, etc.)
# Align bones.
#
# Generate rig.
# Fix rigify bone layers and groups.
# Add twist bones constraints.
# Add DEF- to vertex groups names.

class APEX_OT_GenerateMetarig(bpy.types.Operator):
    bl_label = "Generates an apex metarig from the active armature"
    bl_idname = "apex.generate_metarig"
    bl_description = "Generate apex metarig"
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(self, context):
        if not context.object:
            return False
        return context.object.type == 'ARMATURE'
    
    def execute(self, context):
                
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # TODO: Fix for macos, I think it won't find the files becasue it uses \.
        bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/0initiate_rigify.py")
        bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/1move_bone_layers.py")
        bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/2assign_rig_types.py")
        bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/3fix_metarig_apex_legends.py")
        bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/4align_connect_bones.py")
        
        # Face check.
        for b in context.view_layer.objects.active.data.bones:
            if "jaw" in b.name.lower():
                print("Attempting to fix face rig...")
                bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/a0fix_face_metarig_apex_legends.py")
                bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/a1face_metarig.py")
                break

        bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/6assign_super_copy.py")
#        bpy.ops.script.python_file_run(filepath=script_dir+"/apex_rig/.py")
        
        self.report({'INFO'}, 'Succesfully generated: "apex_legends metarig"')

        return {'FINISHED'}

# ===========================

def register():
    bpy.utils.register_class(APEX_OT_GenerateMetarig)

def unregister():
    bpy.utils.unregister_class(APEX_OT_GenerateMetarig)