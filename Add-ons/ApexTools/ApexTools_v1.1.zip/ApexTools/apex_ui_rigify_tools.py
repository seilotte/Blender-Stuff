import bpy
from bpy.types import Panel
# av = apex_variables

# Global panel UI properties.
class ApexPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Apex'


# Create rigify tools UI panel.
class APEX_PT_RigifyTools(ApexPanel, Panel):
    bl_label = 'Rigify Tools'
    bl_idname = 'APEX_PT_rigify_tools'
#    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        if 'rigify' not in context.preferences.addons.keys():
            self.layout.label(text="Rigify addon is not enabled!", icon="ERROR")
#            return
        else:
            col = self.layout.column(align=True)
            col.operator("apex.generate_metarig", text="Generate Metarig", icon="POSE_HLT")
            col.operator("apex.generate_rigify", text="Generate Rig (fixed)", icon="POSE_HLT")
            
        self.layout.separator()
        
        col = self.layout.column(align=True)
        col.label(text="Metarig Bones", icon="GROUP_BONE")
        col.label(text="From Front View [numpad1]", icon="LAYER_USED")
        
        col.separator()
        
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(context.scene.apex_variables, "root")

# Create body bones UI subpanel.
class APEX_PT_BodyBones(ApexPanel, Panel):
    bl_label = 'Body Bones'
    bl_idname = 'APEX_PT_body_bones'
    bl_parent_id = 'APEX_PT_rigify_tools'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        pass

# Create face bones UI subpanel.
class APEX_PT_FaceBones(ApexPanel, Panel):
    bl_label = 'Face Bones'
    bl_idname = 'APEX_PT_face_bones'
    bl_parent_id = 'APEX_PT_rigify_tools'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        pass


# =========================== Body Bones UI.

# Create columns with an icon.
def apex_row(col, prop_name, prop_text="", row_icon="BLANK1"):
    av = bpy.context.scene.apex_variables
    
    row = col.row(align=True)
    row.label(icon=row_icon)
    row.prop(av, prop_name, text=prop_text)

def apex_row_list(col, my_list, start_name=True, end_name=True):
    av = bpy.context.scene.apex_variables
    
    # Count the strings that are not empty.
    last_string_element = -1 # Last element with a string.
    for c in my_list:
        if hasattr(av, c) and getattr(av, c) != "":
            last_string_element += 1

    for i, item in enumerate(my_list): # Enumerate() gets the index(i) and the "string"(item) of the list.
        if hasattr(av, item) and getattr(av, item) != "":
            if i == 0 and start_name: # first_element
                apex_row(col, item, "Start ", "DISCLOSURE_TRI_RIGHT")
            elif i == last_string_element and end_name:
                apex_row(col, item, "End ", "DISCLOSURE_TRI_RIGHT")
            else:
                apex_row(col, item, " ")
        else:
            apex_row(col, item, "Add? ")
            break



# Create spine bones UI subpanel.
class APEX_PT_SpineBones(ApexPanel, Panel):
    bl_label = 'Spine Bones'
#    bl_idname = 'APEX_PT_spine_bones'
    bl_parent_id = 'APEX_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        col.label(text="Bottom → Top", icon="LAYER_USED")
        apex_row_list(col, av.spine_list)

# Create head bones UI subpanel.
class APEX_PT_HeadBones(ApexPanel, Panel):
    bl_label = 'Head Bones'
#    bl_idname = 'APEX_PT_head_bones'
    bl_parent_id = 'APEX_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        e = -1 # Last element with a string.
        for i in av.spine_list:
            if hasattr(av, i) and getattr(av, i) != "":
                e += 1
        
        #UI
        col.label(text="Bottom → Top", icon="LAYER_USED")
        if e > 0:
            apex_row(col, av.spine_list[e], "Start", "DISCLOSURE_TRI_RIGHT")
        apex_row_list(col, av.head_list, start_name=False)

# Create clavicles bones UI subpanel.
class APEX_PT_ClaviclesBones(ApexPanel, Panel):
    bl_label = 'Clavicles Bones'
#    bl_idname = 'APEX_PT_clavicles_bones'
    bl_parent_id = 'APEX_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        col.label(text="Left → Right", icon="LAYER_USED")
        col.label(text="Left", icon="BONE_DATA")
        apex_row_list(col, av.clavicleL_list)
        
        col.separator(factor=3.0)
        
        col.label(text="Right → Left", icon="LAYER_USED")
        col.label(text="Right", icon="BONE_DATA")
        apex_row_list(col, av.clavicleR_list)

# Create arms bones UI subpanel.
class APEX_PT_ArmsBones(ApexPanel, Panel):
    bl_label = 'Arms Bones'
#    bl_idname = 'APEX_PT_arms_bones'
    bl_parent_id = 'APEX_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        col.label(text="Left → Right", icon="LAYER_USED")
        col.label(text="Left", icon="BONE_DATA")
        apex_row(col, "arm0_L", "Start", "DISCLOSURE_TRI_RIGHT")
        apex_row(col, "arm1_L", " ")
        apex_row(col, "arm2_L", "End", "DISCLOSURE_TRI_RIGHT")
        
        col.separator(factor=3.0)
        
        col.label(text="Right → Left", icon="LAYER_USED")
        col.label(text="Right", icon="BONE_DATA")
        apex_row(col, "arm0_R", "Start", "DISCLOSURE_TRI_RIGHT")
        apex_row(col, "arm1_R", " ")
        apex_row(col, "arm2_R", "End", "DISCLOSURE_TRI_RIGHT")

# Create legs bones UI subpanel.
class APEX_PT_LegsBones(ApexPanel, Panel):
    bl_label = 'Legs Bones'
#    bl_idname = 'APEX_PT_legs_bones'
    bl_parent_id = 'APEX_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        col.label(text="Top → Bottom", icon="LAYER_USED")
        col.label(text="Left", icon="BONE_DATA")
        apex_row_list(col, av.legL_list)
        
        col.separator(factor=3.0)
        
        col.label(text="Top → Bottom", icon="LAYER_USED")
        col.label(text="Right", icon="BONE_DATA")
        apex_row_list(col, av.legR_list)

# Create fingers bones UI subpanel.
class APEX_PT_FingersBones(ApexPanel, Panel):
    bl_label = 'Fingers Bones'
#    bl_idname = 'APEX_PT_finger_bones'
    bl_parent_id = 'APEX_PT_body_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        # User Interface.
        col.label(text="Left", icon="BONE_DATA")
        for i in av.fingersL_list:
            col.prop(av, i)
        
        col.separator(factor=3.0)
        
        col.label(text="Right", icon="BONE_DATA")
        for i in av.fingersR_list:
            col.prop(av, i)

# =========================== Face Bones UI.

# Create eyebrows bones UI subpanel.
class APEX_PT_EyebrowsBones(ApexPanel, Panel):
    bl_label = 'Eyebrows Bones'
#    bl_idname = 'APEX_PT_eyebrows_bones'
    bl_parent_id = 'APEX_PT_face_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        col.label(text="Right → Left", icon="LAYER_USED")
        col.label(text="Left", icon="BONE_DATA")
        apex_row_list(col, av.eyebrowL_list)
        
        col.separator(factor=3.0)
        
        col.label(text="Left → Right", icon="LAYER_USED")
        col.label(text="Right", icon="BONE_DATA")
        apex_row_list(col, av.eyebrowR_list)

# Create left eye bones UI subpanel.
class APEX_PT_LeftEyeBones(ApexPanel, Panel):
    bl_label = 'Left Eye Bones'
#    bl_idname = 'APEX_PT_left_eye_bones'
    bl_parent_id = 'APEX_PT_face_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "eye_L", text="Eye")
        
        col.separator(factor=3.0)
        
        col.label(text="Right → Left", icon="LAYER_USED")
        col.label(text="Top", icon="BONE_DATA")
        apex_row_list(col, av.eyeTL_list)
        col.separator(factor=3.0)
        col.label(text="Left → Right", icon="LAYER_USED")
        col.label(text="Bottom", icon="BONE_DATA")
        apex_row_list(col, av.eyeBL_list)

# Create right eye bones UI subpanel.
class APEX_PT_RightEyeBones(ApexPanel, Panel):
    bl_label = 'Right Eye Bones'
#    bl_idname = 'APEX_PT_right_eye_bones'
    bl_parent_id = 'APEX_PT_face_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        # UI.
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "eye_R", text="Eye")
        
        col.separator(factor=3.0)
        
        col.label(text="Left → Right", icon="LAYER_USED")
        col.label(text="Top", icon="BONE_DATA")
        apex_row_list(col, av.eyeTR_list)
        col.separator(factor=3.0)
        col.label(text="Right → Left", icon="LAYER_USED")
        col.label(text="Bottom", icon="BONE_DATA")
        apex_row_list(col, av.eyeBR_list)

# =========================== Mouth Bones UI.

# Create mouth bones UI subpanel.
class APEX_PT_MouthBones(ApexPanel, Panel):
    bl_label= 'Mouth Bones'
    bl_idname = 'APEX_PT_mouth_bones'
    bl_parent_id = 'APEX_PT_face_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True)
        
        #UI.
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "jaw")
        
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "chin")
        
        col.separator()
        
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "teeth_T")
        
        row = col.row(align=True)
        row.label(icon="BONE_DATA")
        row.prop(av, "teeth_B")

# Create lips bones UI subpanel.
class APEX_PT_LeftLipsBones(ApexPanel, Panel):
    bl_label = 'Left Lips Bones'
#    bl_idname = 'APEX_PT_left_lips_bones'
    bl_parent_id = 'APEX_PT_mouth_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        f = -1 # Last element with a string.
        for i  in av.lipTL_list:
            if hasattr(av, i) and getattr(av, i) != "":
                f += 1
        
        # UI.
        col.label(text="Middle → Right", icon="LAYER_USED")
        col.label(text="Top", icon="BONE_DATA")
        row = col.row(align=True) # Icon + row.
        row.label(icon="DISCLOSURE_TRI_RIGHT")
        row.prop(av, "lip_C_T", text="Start") # Center top.
        
        apex_row_list(col, av.lipTL_list, False) # Disable start.
        
        col.separator(factor=3.0)
        
        col.label(text="Middle → Right", icon="LAYER_USED")
        col.label(text="Bottom", icon="BONE_DATA")
        row = col.row(align=True) # Icon + row.
        row.label(icon="DISCLOSURE_TRI_RIGHT")
        row.prop(av, "lip_C_B", text="Start") # Center bottom.
        
        apex_row_list(col, av.lipBL_list, False, False) # Disable start and end.
        if f > 0:
            apex_row(col, av.lipTL_list[f], "End", "DISCLOSURE_TRI_RIGHT")

# Create lips bones UI subpanel.
class APEX_PT_RightLipsBones(ApexPanel, Panel):
    bl_label = 'Right Lips Bones'
#    bl_idname = 'APEX_PT_right_lips_bones'
    bl_parent_id = 'APEX_PT_mouth_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align=True) # Main column.
        
        g = -1 # Last element with a string.
        for i in av.lipTR_list:
            if hasattr(av, i) and getattr(av, i) != "":
                g += 1
        
        #UI
        col.label(text="Middle → Left", icon="LAYER_USED")
        col.label(text="Top", icon="BONE_DATA")
        row = col.row(align=True) # Icon + row.
        row.label(icon="DISCLOSURE_TRI_RIGHT")
        row.prop(av, "lip_C_T", text="Start") # Center top.
        
        apex_row_list(col, av.lipTR_list, False) # Disable start.
        
        col.separator(factor=3.0)
        
        col.label(text="Middle → Left", icon="LAYER_USED")
        col.label(text="Bottom", icon="BONE_DATA")
        row = col.row(align=True) # Icon + row.
        row.label(icon="DISCLOSURE_TRI_RIGHT")
        row.prop(av, "lip_C_B", text="Start") # Center bottom.
        
        apex_row_list(col, av.lipBR_list, False, False) # Disable start and end.
        if g > 0:
            apex_row(col, av.lipTR_list[g], "End", "DISCLOSURE_TRI_RIGHT")

# Create tongue bones UI subpanel.
class APEX_PT_TongueBones(ApexPanel, Panel):
    bl_label = 'Tongue Bones'
#    bl_idname = 'APEX_PT_tongue_bones'
    bl_parent_id = 'APEX_PT_mouth_bones'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        av = context.scene.apex_variables
        col = self.layout.column(align = True) # Main column.
        
        #UI.
        col.label(text="Tip → End", icon="LAYER_USED")
        apex_row_list(col, av.tongue_list)

# ===========================

classes = [
    APEX_PT_RigifyTools,
    APEX_PT_BodyBones,
    APEX_PT_FaceBones,
    
    APEX_PT_SpineBones,
    APEX_PT_HeadBones,
    APEX_PT_ClaviclesBones,
    APEX_PT_ArmsBones,
    APEX_PT_LegsBones,
    APEX_PT_FingersBones,
    
    APEX_PT_EyebrowsBones,
    APEX_PT_LeftEyeBones,
    APEX_PT_RightEyeBones,
    
    APEX_PT_MouthBones,
    APEX_PT_LeftLipsBones,
    APEX_PT_RightLipsBones,
    APEX_PT_TongueBones,
]
def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)