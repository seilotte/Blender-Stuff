import bpy
from bpy.types import Panel, Operator
from math import radians

# Fix and apply rotation & scale.
class APEX_OT_FixSizeRot(Operator):
    bl_label = "Fix Size and Rotation"
    bl_idname = "apex.ot_fixsizerot"
    bl_description = "Apply correct scale and rotation"
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        
        for o in context.selected_objects:
            if o.type == 'ARMATURE':
                o.rotation_euler[0] = radians(90)
                for n in range(3):
                    o.scale[n] = 0.0254 
            
#            if o.type in ['MESH', 'ARMATURE']:
            if o.type == 'ARMATURE' or o.type == 'MESH':
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

        return{'FINISHED'}

# Fix names.
class APEX_OT_FixNames(Operator):
    bl_label = "Apply Material Names to Objects"
    bl_idname = "apex.ot_fixnames"
    bl_description = "Rename mesh-object names with the respective material"
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):

        for o in context.selected_objects:
            if o.type == 'MESH':
                for mSlot in o.material_slots:
                    o.name = mSlot.name
                    o.data.name = o.name

        return{'FINISHED'}


def add_camera(name, bone_name, fov=None):
    if name in bpy.data.objects:
        return bpy.data.objects[name]

    cam = bpy.data.objects.new(name, bpy.data.cameras.new(name))
    bpy.context.scene.collection.objects.link(cam)
    if fov:
        cam.data.lens_unit = 'FOV'
        cam.data.angle = radians(fov)
    # Add constraint.
    if bpy.context.scene.apex_variables.from_armature:
        constraint = cam.constraints.new('COPY_TRANSFORMS')
        constraint.target = bpy.context.scene.apex_variables.from_armature
        if bone_name in bpy.context.scene.apex_variables.from_armature.data.bones:
            constraint.subtarget = bone_name
        else:
            bpy.data.cameras.remove(bpy.data.objects[name].data)
            print("The armature does not have the apex camera bones.")

# Apply pov camera to bone.
class APEX_OT_ApexPovCamera(Operator):
    bl_label = "Parent Pov Camera to an Apex_Bone."
    bl_idname = "apex.ot_apexpovcamera"
    bl_description = 'Create "Pov_Camera" and parent it to the respective apex_bone'
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(self, context):
        obj = context.scene.apex_variables.from_armature
        if not obj:
            return False
        return obj.type == 'ARMATURE'
    
    def execute(self, context):

        add_camera("Pov_Camera", "jx_c_pov", 90)

        return{'FINISHED'}

# Apply apex camera to bone.
class APEX_OT_ApexCamera(Operator):
    bl_label = "Parent Apex Camera to an Apex_Bone."
    bl_idname = "apex.ot_apexcamera"
    bl_description = 'Create "Apex_Camera" and parent it to the respective apex_bone'
    bl_region_type = 'UI'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(self, context):
        obj = context.scene.apex_variables.from_armature
        if not obj:
            return False
        return obj.type == 'ARMATURE'
    
    def execute(self, context):

        add_camera("Apex_Camera", "jx_c_camera")

        return{'FINISHED'}

# ===========================

# Global panel UI properties.
class ApexPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Apex'

# Create data tools UI panel.
class APEX_PT_DataTools(ApexPanel, Panel):
    bl_label = 'Data Tools'
    bl_idname = 'APEX_PT_datatools'
#    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        
        col = layout.column(align=True)
        col.prop(context.scene.apex_variables, 'from_armature', text="Rig")
        col.operator('apex.ot_assignrig', text="Assign Armature", icon='OUTLINER_OB_ARMATURE')
        row = col.split(factor=0.5, align=True)
        row.operator('apex.ot_apexcamera', text="Add ApexCamera", icon='VIEW_CAMERA')
        row.operator('apex.ot_apexpovcamera', text="Add PovCamera", icon='VIEW_CAMERA')
        
        layout.separator()
        
        col = layout.column(align=True)
        col.operator('apex.ot_fixsizerot', text="Fix Rotation & Scale", icon='MESH_DATA')
        col.operator('apex.ot_fixnames', text="Rename Objects", icon='OUTLINER_OB_MESH')
#                    row.prop(context.object.data, 'show_axes', text="Axes")
        layout.operator("outliner.orphans_purge", text="Purge", icon='TRASH').do_recursive = True

# Create nodes data UI subpanel.
class APEX_PT_NodesData(ApexPanel, Panel):
    bl_label = 'Nodes Data'
    bl_parent_id = 'APEX_PT_datatools'
#    bl_option = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        apex_vars = context.scene.apex_variables
        
#        layout.label(text="Auto Texture", icon='IMAGE_DATA')
        col = layout.column(align=True)
        col.prop(apex_vars, "dir", text="")
        col.operator('apex.ot_batch_mats', text="Auto Texture", icon='IMAGE_DATA')
        col.prop(apex_vars, "aoNode")
 
# ===========================

classes = [
    APEX_OT_FixSizeRot,
    APEX_OT_FixNames,
    APEX_OT_ApexPovCamera,
    APEX_OT_ApexCamera,
    APEX_PT_DataTools,
    APEX_PT_NodesData,
]
def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)